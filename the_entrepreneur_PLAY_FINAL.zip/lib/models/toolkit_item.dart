class ToolkitItem {
  final String id;
  final String title;
  final String category;
  final String content;

  const ToolkitItem({
    required this.id,
    required this.title,
    required this.category,
    required this.content,
  });
}
