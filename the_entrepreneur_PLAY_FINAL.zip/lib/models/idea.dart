const List<String> ideaStatuses = ['Spark', 'Validating', 'Building', 'Launched', 'Parked'];

class Idea {
  final int? id;
  final String title;
  final String problem;
  final String customer;
  final String solution;
  final String notes;
  final String status;
  final int pain;
  final int market;
  final int timing;
  final int reach;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Idea({
    this.id,
    required this.title,
    required this.problem,
    required this.customer,
    required this.solution,
    required this.notes,
    required this.status,
    required this.pain,
    required this.market,
    required this.timing,
    required this.reach,
    required this.createdAt,
    required this.updatedAt,
  });

  /// Opportunity score from 0 to 100, built from four 1 to 5 ratings.
  int get score => ((pain + market + timing + reach) / 20 * 100).round();

  Map<String, Object?> toMap() => {
        'title': title,
        'problem': problem,
        'customer': customer,
        'solution': solution,
        'notes': notes,
        'status': status,
        'pain': pain,
        'market': market,
        'timing': timing,
        'reach': reach,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Idea.fromMap(Map<String, Object?> m) {
    return Idea(
      id: m['id'] as int?,
      title: (m['title'] as String?) ?? '',
      problem: (m['problem'] as String?) ?? '',
      customer: (m['customer'] as String?) ?? '',
      solution: (m['solution'] as String?) ?? '',
      notes: (m['notes'] as String?) ?? '',
      status: (m['status'] as String?) ?? 'Spark',
      pain: (m['pain'] as int?) ?? 3,
      market: (m['market'] as int?) ?? 3,
      timing: (m['timing'] as int?) ?? 3,
      reach: (m['reach'] as int?) ?? 3,
      createdAt: DateTime.tryParse((m['created_at'] as String?) ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse((m['updated_at'] as String?) ?? '') ?? DateTime.now(),
    );
  }
}
