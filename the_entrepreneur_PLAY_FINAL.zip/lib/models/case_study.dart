class FounderChapter {
  final int number;
  final String title;
  final String content;

  const FounderChapter({
    required this.number,
    required this.title,
    required this.content,
  });
}

class DeepFounder {
  final String id;
  final String name;
  final String company;
  final List<FounderChapter> chapters;

  const DeepFounder({
    required this.id,
    required this.name,
    required this.company,
    required this.chapters,
  });
}

class ShortCase {
  final String id;
  final String company;
  final String story;
  final String lesson;

  const ShortCase({
    required this.id,
    required this.company,
    required this.story,
    required this.lesson,
  });
}
