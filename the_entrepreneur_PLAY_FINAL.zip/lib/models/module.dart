class Lesson {
  final String id;
  final String title;
  final String principle;
  final String story;
  final List<String> bestPractices;
  final String reflection;

  const Lesson({
    required this.id,
    required this.title,
    required this.principle,
    required this.story,
    required this.bestPractices,
    required this.reflection,
  });
}

class Module {
  final String id;
  final int number;
  final String title;
  final String description;
  final int colorValue;
  final bool isFree;
  final List<Lesson> lessons;

  const Module({
    required this.id,
    required this.number,
    required this.title,
    required this.description,
    required this.colorValue,
    required this.isFree,
    required this.lessons,
  });
}
