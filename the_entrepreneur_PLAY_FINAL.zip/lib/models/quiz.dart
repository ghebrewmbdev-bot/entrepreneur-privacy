class QuizQuestion {
  final String prompt;
  final List<String> options;
  final int answer;
  final String explanation;

  const QuizQuestion({
    required this.prompt,
    required this.options,
    required this.answer,
    required this.explanation,
  });
}
