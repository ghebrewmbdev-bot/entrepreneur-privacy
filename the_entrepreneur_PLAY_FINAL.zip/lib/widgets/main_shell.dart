import 'package:flutter/material.dart';
import '../screens/home_screen.dart';
import '../screens/modules_screen.dart';
import '../screens/stories_screen.dart';
import '../screens/toolkit_screen.dart';
import '../screens/profile_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  static const List<Widget> _screens = [
    HomeScreen(),
    ModulesScreen(),
    StoriesScreen(),
    ToolkitScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    // The active tab is rebuilt each time it is selected, so progress,
    // streaks, and badges are always fresh when you switch back to it.
    return Scaffold(
      body: _screens[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.grid_view_rounded), label: 'Modules'),
          BottomNavigationBarItem(icon: Icon(Icons.auto_stories_rounded), label: 'Stories'),
          BottomNavigationBarItem(icon: Icon(Icons.handyman_rounded), label: 'Toolkit'),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}
