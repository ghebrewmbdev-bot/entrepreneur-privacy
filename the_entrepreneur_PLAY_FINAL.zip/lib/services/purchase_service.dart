import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'progress_db.dart';

// DORMANT while every module is free (isFree: true in modules_catalog.dart).
// When you turn paid modules on later, create this product in Play Console
// with the exact id below (one-time, non-consumable). The id follows the
// real applicationId com.weegix.entrepreneur.
const String kUnlockAllProductId = 'com.weegix.entrepreneur.unlock_all';

class PurchaseService {
  PurchaseService._();
  static final PurchaseService instance = PurchaseService._();

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;
  List<ProductDetails> _products = [];
  bool _available = false;
  bool _initialized = false;

  bool get storeAvailable => _available;
  List<ProductDetails> get products => _products;

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      _available = await _iap.isAvailable();
      if (!_available) return;

      final response = await _iap.queryProductDetails({kUnlockAllProductId});
      _products = response.productDetails;

      _subscription = _iap.purchaseStream.listen(
        _onPurchaseUpdate,
        onDone: () => _subscription?.cancel(),
        onError: (Object error) {},
      );

      // Restore any prior purchase on launch (for example after a reinstall).
      await _iap.restorePurchases();
    } catch (_) {
      _available = false;
    }
  }

  Future<void> _onPurchaseUpdate(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.productID == kUnlockAllProductId) {
        if (purchase.status == PurchaseStatus.purchased || purchase.status == PurchaseStatus.restored) {
          await ProgressDb.instance.setUnlocked(true);
        }
        if (purchase.pendingCompletePurchase) {
          await _iap.completePurchase(purchase);
        }
      }
    }
  }

  Future<void> buyUnlockAll() async {
    if (!_available || _products.isEmpty) return;
    final product = _products.firstWhere((p) => p.id == kUnlockAllProductId);
    final param = PurchaseParam(productDetails: product);
    await _iap.buyNonConsumable(purchaseParam: param);
  }

  Future<void> restorePurchases() async {
    try {
      await _iap.restorePurchases();
    } catch (_) {}
  }

  void dispose() {
    _subscription?.cancel();
  }
}
