import 'package:flutter/material.dart';
import '../models/module.dart';
import '../services/progress_db.dart';
import '../screens/lesson_list_screen.dart';
import '../screens/paywall_screen.dart';

/// Single navigation choke point for opening a module's lesson list.
/// Every screen routes through this so the paywall gate stays consistent.
/// While every module has isFree: true the paywall is never shown.
/// The returned Future completes when the opened screen is closed, so
/// callers can refresh their progress afterwards.
class ModuleNavigation {
  static Future<void> openModule(BuildContext context, Module module) async {
    bool allowed = module.isFree;
    if (!allowed) {
      allowed = await ProgressDb.instance.isUnlocked();
    }
    if (!context.mounted) return;
    if (allowed) {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => LessonListScreen(module: module)),
      );
    } else {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const PaywallScreen()),
      );
    }
  }
}
