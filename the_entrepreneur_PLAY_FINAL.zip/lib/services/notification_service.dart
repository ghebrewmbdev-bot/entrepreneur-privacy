import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'progress_db.dart';

class ReminderSettings {
  final bool enabled;
  final int hour;
  final int minute;
  const ReminderSettings({required this.enabled, required this.hour, required this.minute});
}

/// Local, on-device daily reminder. No server, no data leaves the phone.
///
/// The reminder is scheduled as a fixed instant (UTC) computed from the
/// phone's local time. It is recomputed every time the app opens, so a
/// daylight saving change corrects itself the next time the app launches.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  static const String _kEnabled = 'reminder_enabled';
  static const String _kHour = 'reminder_hour';
  static const String _kMinute = 'reminder_minute';
  static const int _notifId = 1001;

  Future<void> init() async {
    if (_ready) return;
    try {
      tzdata.initializeTimeZones();
      const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(const InitializationSettings(android: androidInit));
      _ready = true;
      await rescheduleFromSettings();
    } catch (_) {
      // Notifications are a convenience. Never crash the app over them.
    }
  }

  Future<bool> requestPermission() async {
    try {
      await init();
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final granted = await android?.requestNotificationsPermission();
      return granted ?? true;
    } catch (_) {
      return false;
    }
  }

  Future<ReminderSettings> getReminder() async {
    final db = ProgressDb.instance;
    final enabled = (await db.getSetting(_kEnabled)) == '1';
    final hour = int.tryParse((await db.getSetting(_kHour)) ?? '') ?? 8;
    final minute = int.tryParse((await db.getSetting(_kMinute)) ?? '') ?? 0;
    return ReminderSettings(enabled: enabled, hour: hour, minute: minute);
  }

  Future<void> setReminder(bool enabled, int hour, int minute) async {
    final db = ProgressDb.instance;
    await db.setSetting(_kEnabled, enabled ? '1' : '0');
    await db.setSetting(_kHour, hour.toString());
    await db.setSetting(_kMinute, minute.toString());
    await init();
    if (enabled) {
      await _schedule(hour, minute);
    } else {
      await _cancel();
    }
  }

  Future<void> rescheduleFromSettings() async {
    final r = await getReminder();
    if (r.enabled) {
      await _schedule(r.hour, r.minute);
    }
  }

  Future<void> _cancel() async {
    if (!_ready) return;
    try {
      await _plugin.cancel(_notifId);
    } catch (_) {}
  }

  Future<void> _schedule(int hour, int minute) async {
    if (!_ready) return;
    try {
      final now = DateTime.now();
      var next = DateTime(now.year, now.month, now.day, hour, minute);
      if (!next.isAfter(now)) {
        next = next.add(const Duration(days: 1));
      }
      final when = tz.TZDateTime.from(next, tz.UTC);
      await _plugin.zonedSchedule(
        _notifId,
        'Time to think like a founder',
        'Your daily challenge is ready. Five minutes is enough.',
        when,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'daily_challenge',
            'Daily challenge',
            channelDescription: 'Daily reminder to complete your entrepreneur challenge',
            importance: Importance.defaultImportance,
            priority: Priority.defaultPriority,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    } catch (_) {}
  }
}
