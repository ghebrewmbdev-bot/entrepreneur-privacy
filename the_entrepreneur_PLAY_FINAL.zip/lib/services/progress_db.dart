import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/idea.dart';

class ProgressDb {
  ProgressDb._();
  static final ProgressDb instance = ProgressDb._();
  Database? _db;

  // v1: completed lessons, daily log, entitlement
  // v2: settings (key/value), ideas (Idea Lab)
  static const int _dbVersion = 3;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'the_entrepreneur.db');
    return openDatabase(
      path,
      version: _dbVersion,
      onCreate: (db, version) async {
        await _createV1(db);
        await _createV2(db);
        await _createV3(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await _createV2(db);
        }
        if (oldVersion < 3) {
          await _createV3(db);
        }
      },
    );
  }

  Future<void> _createV1(Database db) async {
    await db.execute('''
      CREATE TABLE completed_lessons (
        lesson_id TEXT PRIMARY KEY,
        completed_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE daily_log (
        log_date TEXT PRIMARY KEY,
        challenge_index INTEGER,
        completed INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE entitlement (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        unlocked INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.insert('entitlement', {'id': 1, 'unlocked': 0});
  }

  Future<void> _createV2(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS ideas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        problem TEXT,
        customer TEXT,
        solution TEXT,
        notes TEXT,
        status TEXT NOT NULL,
        pain INTEGER,
        market INTEGER,
        timing INTEGER,
        reach INTEGER,
        created_at TEXT,
        updated_at TEXT
      )
    ''');
  }

  Future<void> _createV3(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS quiz_scores (
        module_id TEXT PRIMARY KEY,
        best INTEGER NOT NULL,
        total INTEGER NOT NULL,
        updated_at TEXT
      )
    ''');
  }

  // ---- Quiz scores ----
  Future<void> saveQuizScore(String moduleId, int score, int total) async {
    final db = await database;
    final rows = await db.query('quiz_scores', where: 'module_id = ?', whereArgs: [moduleId]);
    if (rows.isNotEmpty && (rows.first['best'] as int) >= score) return;
    await db.insert(
      'quiz_scores',
      {'module_id': moduleId, 'best': score, 'total': total, 'updated_at': DateTime.now().toIso8601String()},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Best score per module id, as {moduleId: [best, total]}.
  Future<Map<String, List<int>>> getQuizScores() async {
    final db = await database;
    final rows = await db.query('quiz_scores');
    return {for (final r in rows) r['module_id'] as String: [r['best'] as int, r['total'] as int]};
  }

  // ---- Settings ----
  Future<String?> getSetting(String key) async {
    final db = await database;
    final rows = await db.query('settings', where: 'key = ?', whereArgs: [key]);
    if (rows.isEmpty) return null;
    return rows.first['value'] as String?;
  }

  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert(
      'settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ---- Lessons ----
  Future<void> markLessonComplete(String lessonId) async {
    final db = await database;
    await db.insert(
      'completed_lessons',
      {'lesson_id': lessonId, 'completed_at': DateTime.now().toIso8601String()},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> unmarkLessonComplete(String lessonId) async {
    final db = await database;
    await db.delete('completed_lessons', where: 'lesson_id = ?', whereArgs: [lessonId]);
  }

  Future<Set<String>> getCompletedLessonIds() async {
    final db = await database;
    final rows = await db.query('completed_lessons');
    return rows.map((r) => r['lesson_id'] as String).toSet();
  }

  // ---- Daily challenge and streak ----
  Future<void> markTodayComplete(int challengeIndex) async {
    final db = await database;
    final todayKey = _dateKey(DateTime.now());
    await db.insert(
      'daily_log',
      {'log_date': todayKey, 'challenge_index': challengeIndex, 'completed': 1},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<bool> isTodayComplete() async {
    final db = await database;
    final todayKey = _dateKey(DateTime.now());
    final rows = await db.query('daily_log', where: 'log_date = ?', whereArgs: [todayKey]);
    return rows.isNotEmpty && rows.first['completed'] == 1;
  }

  /// Current streak. If today is not done yet, the streak still counts
  /// through yesterday so it does not show 0 first thing in the morning.
  Future<int> getCurrentStreak() async {
    final db = await database;
    DateTime cursor = DateTime.now();
    if (!await isTodayComplete()) {
      cursor = cursor.subtract(const Duration(days: 1));
    }
    int streak = 0;
    while (true) {
      final key = _dateKey(cursor);
      final rows = await db.query('daily_log', where: 'log_date = ? AND completed = 1', whereArgs: [key]);
      if (rows.isEmpty) break;
      streak++;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return streak;
  }

  Future<int> getLongestStreak() async {
    final db = await database;
    final rows = await db.query(
      'daily_log',
      columns: ['log_date'],
      where: 'completed = 1',
      orderBy: 'log_date ASC',
    );
    int longest = 0;
    int run = 0;
    DateTime? prev;
    for (final r in rows) {
      final parts = (r['log_date'] as String).split('-');
      if (parts.length != 3) continue;
      final d = DateTime.utc(int.parse(parts[0]), int.parse(parts[1]), int.parse(parts[2]));
      if (prev != null && d.difference(prev).inDays == 1) {
        run++;
      } else {
        run = 1;
      }
      if (run > longest) longest = run;
      prev = d;
    }
    return longest;
  }

  Future<int> getCompletedChallengeCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS c FROM daily_log WHERE completed = 1');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  String _dateKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  // ---- Ideas (Idea Lab) ----
  Future<List<Idea>> getIdeas() async {
    final db = await database;
    final rows = await db.query('ideas', orderBy: 'updated_at DESC');
    return rows.map((r) => Idea.fromMap(r)).toList();
  }

  Future<int> saveIdea(Idea idea) async {
    final db = await database;
    if (idea.id == null) {
      return db.insert('ideas', idea.toMap());
    }
    await db.update('ideas', idea.toMap(), where: 'id = ?', whereArgs: [idea.id]);
    return idea.id!;
  }

  Future<void> deleteIdea(int id) async {
    final db = await database;
    await db.delete('ideas', where: 'id = ?', whereArgs: [id]);
  }

  // ---- Reset ----
  Future<void> resetLearningProgress() async {
    final db = await database;
    await db.delete('completed_lessons');
    await db.delete('daily_log');
    await db.delete('quiz_scores');
  }

  // ---- Entitlement (local cache; real check happens via PurchaseService) ----
  Future<bool> isUnlocked() async {
    final db = await database;
    final rows = await db.query('entitlement', where: 'id = 1');
    if (rows.isEmpty) return false;
    return rows.first['unlocked'] == 1;
  }

  Future<void> setUnlocked(bool unlocked) async {
    final db = await database;
    await db.update('entitlement', {'unlocked': unlocked ? 1 : 0}, where: 'id = 1');
  }
}
