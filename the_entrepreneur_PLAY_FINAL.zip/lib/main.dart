import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'widgets/main_shell.dart';
import 'screens/onboarding_screen.dart';
import 'services/progress_db.dart';
import 'services/notification_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TheEntrepreneurApp());
}

class TheEntrepreneurApp extends StatelessWidget {
  const TheEntrepreneurApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'The Entrepreneur',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.light,
      theme: AppTheme.light,
      home: const _Gate(),
    );
  }
}

/// Shows onboarding on the very first launch, then the main app.
class _Gate extends StatefulWidget {
  const _Gate();

  @override
  State<_Gate> createState() => _GateState();
}

class _GateState extends State<_Gate> {
  bool? _onboarded;

  @override
  void initState() {
    super.initState();
    _check();
    // Re-arms the daily reminder (if enabled) every time the app opens.
    NotificationService.instance.init();
  }

  Future<void> _check() async {
    final v = await ProgressDb.instance.getSetting('onboarded');
    if (mounted) setState(() => _onboarded = v == '1');
  }

  Future<void> _finishOnboarding() async {
    await ProgressDb.instance.setSetting('onboarded', '1');
    if (mounted) setState(() => _onboarded = true);
  }

  @override
  Widget build(BuildContext context) {
    final onboarded = _onboarded;
    if (onboarded == null) {
      return const Scaffold(
        backgroundColor: AppColors.navy,
        body: Center(child: CircularProgressIndicator(color: AppColors.gold)),
      );
    }
    if (!onboarded) {
      return OnboardingScreen(onDone: _finishOnboarding);
    }
    return const MainShell();
  }
}
