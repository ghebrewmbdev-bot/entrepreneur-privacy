import 'package:flutter/material.dart';

// Fonts are bundled with the app (Inter for body text, Space Grotesk for
// headings), so nothing is downloaded at runtime.
const String kBodyFont = 'Inter';
const String kHeadingFont = 'SpaceGrotesk';

class AppColors {
  static const navy = Color(0xFF0E1B33);
  static const navyLight = Color(0xFF152744);
  static const teal = Color(0xFF1E7A75);
  static const tealLight = Color(0xFFDCF0EE);
  static const gold = Color(0xFFC9A24B);
  static const cream = Color(0xFFF7F4EC);
  static const ink = Color(0xFF1B1B1B);
  static const muted = Color(0xFF6B7280);
  static const cardBorder = Color(0xFFE7E3D6);

  // Module accent colors, matching the HTML preview
  static const moduleColors = [
    Color(0xFFD4537E),
    Color(0xFF378ADD),
    Color(0xFFEF9F27),
    Color(0xFF7F77DD),
    Color(0xFF1D9E75),
    Color(0xFFE24B4A),
    Color(0xFF534AB7),
    Color(0xFF0F8B8D),
    Color(0xFFB5651D),
    Color(0xFF8E3B46),
  ];
}

class AppTheme {
  static ThemeData get light {
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.cream,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.navy,
        secondary: AppColors.teal,
        tertiary: AppColors.gold,
        surface: AppColors.cream,
      ),
      textTheme: base.textTheme.apply(fontFamily: kBodyFont).copyWith(
        displayLarge: const TextStyle(fontFamily: kHeadingFont, fontWeight: FontWeight.w600),
        displayMedium: const TextStyle(fontFamily: kHeadingFont, fontWeight: FontWeight.w600),
        headlineLarge: const TextStyle(fontFamily: kHeadingFont, fontWeight: FontWeight.w600),
        headlineMedium: const TextStyle(fontFamily: kHeadingFont, fontWeight: FontWeight.w600),
        headlineSmall: const TextStyle(fontFamily: kHeadingFont, fontWeight: FontWeight.w600),
        titleLarge: const TextStyle(fontFamily: kHeadingFont, fontWeight: FontWeight.w600),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        titleTextStyle: const TextStyle(
          fontFamily: kHeadingFont,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: AppColors.teal,
        unselectedItemColor: Color(0xFFB3B0A2),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.navy,
          textStyle: const TextStyle(fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: AppColors.cardBorder),
        ),
      ),
    );
  }
}
