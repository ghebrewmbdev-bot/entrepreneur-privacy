import 'package:flutter/material.dart';
import '../services/progress_db.dart';
import 'modules_catalog.dart';

class AchievementStats {
  final int lessonsDone;
  final int totalLessons;
  final int modulesDone;
  final int totalModules;
  final int streak;
  final int longestStreak;
  final int challenges;
  final int ideas;
  final int ideasAdvanced;
  final int quizzesPassed;
  final int perfectQuizzes;

  const AchievementStats({
    required this.lessonsDone,
    required this.totalLessons,
    required this.modulesDone,
    required this.totalModules,
    required this.streak,
    required this.longestStreak,
    required this.challenges,
    required this.ideas,
    required this.ideasAdvanced,
    this.quizzesPassed = 0,
    this.perfectQuizzes = 0,
  });
}

class Achievement {
  final String id;
  final String title;
  final String description;
  final IconData icon;
  final bool Function(AchievementStats s) isUnlocked;

  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.isUnlocked,
  });
}

final List<Achievement> achievements = [
  Achievement(
    id: 'first_lesson',
    title: 'First Step',
    description: 'Finish your first lesson.',
    icon: Icons.flag_rounded,
    isUnlocked: (s) => s.lessonsDone >= 1,
  ),
  Achievement(
    id: 'five_lessons',
    title: 'Getting Warm',
    description: 'Finish 5 lessons.',
    icon: Icons.local_fire_department_rounded,
    isUnlocked: (s) => s.lessonsDone >= 5,
  ),
  Achievement(
    id: 'ten_lessons',
    title: 'Double Digits',
    description: 'Finish 10 lessons.',
    icon: Icons.menu_book_rounded,
    isUnlocked: (s) => s.lessonsDone >= 10,
  ),
  Achievement(
    id: 'twenty_five_lessons',
    title: 'Deep Student',
    description: 'Finish 25 lessons.',
    icon: Icons.school_rounded,
    isUnlocked: (s) => s.lessonsDone >= 25,
  ),
  Achievement(
    id: 'all_lessons',
    title: 'Complete Founder',
    description: 'Finish every lesson in every module.',
    icon: Icons.workspace_premium_rounded,
    isUnlocked: (s) => s.totalLessons > 0 && s.lessonsDone >= s.totalLessons,
  ),
  Achievement(
    id: 'first_module',
    title: 'Module Master',
    description: 'Complete one full module.',
    icon: Icons.check_circle_rounded,
    isUnlocked: (s) => s.modulesDone >= 1,
  ),
  Achievement(
    id: 'three_modules',
    title: 'Triple Threat',
    description: 'Complete 3 full modules.',
    icon: Icons.looks_3_rounded,
    isUnlocked: (s) => s.modulesDone >= 3,
  ),
  Achievement(
    id: 'all_modules',
    title: 'Full Stack Founder',
    description: 'Complete every module.',
    icon: Icons.emoji_events_rounded,
    isUnlocked: (s) => s.totalModules > 0 && s.modulesDone >= s.totalModules,
  ),
  Achievement(
    id: 'streak_3',
    title: 'Three in a Row',
    description: 'Reach a 3-day challenge streak.',
    icon: Icons.bolt_rounded,
    isUnlocked: (s) => s.longestStreak >= 3,
  ),
  Achievement(
    id: 'streak_7',
    title: 'One Week Strong',
    description: 'Reach a 7-day challenge streak.',
    icon: Icons.date_range_rounded,
    isUnlocked: (s) => s.longestStreak >= 7,
  ),
  Achievement(
    id: 'streak_14',
    title: 'Fortnight Focus',
    description: 'Reach a 14-day challenge streak.',
    icon: Icons.trending_up_rounded,
    isUnlocked: (s) => s.longestStreak >= 14,
  ),
  Achievement(
    id: 'streak_30',
    title: 'Habit Built',
    description: 'Reach a 30-day challenge streak.',
    icon: Icons.military_tech_rounded,
    isUnlocked: (s) => s.longestStreak >= 30,
  ),
  Achievement(
    id: 'challenge_1',
    title: 'Challenge Accepted',
    description: 'Complete your first daily challenge.',
    icon: Icons.task_alt_rounded,
    isUnlocked: (s) => s.challenges >= 1,
  ),
  Achievement(
    id: 'challenge_10',
    title: 'Ten Challenges',
    description: 'Complete 10 daily challenges.',
    icon: Icons.checklist_rounded,
    isUnlocked: (s) => s.challenges >= 10,
  ),
  Achievement(
    id: 'challenge_30',
    title: 'Full Cycle',
    description: 'Complete 30 daily challenges.',
    icon: Icons.autorenew_rounded,
    isUnlocked: (s) => s.challenges >= 30,
  ),
  Achievement(
    id: 'idea_1',
    title: 'First Spark',
    description: 'Save your first idea in the Idea Lab.',
    icon: Icons.lightbulb_rounded,
    isUnlocked: (s) => s.ideas >= 1,
  ),
  Achievement(
    id: 'idea_3',
    title: 'Idea Machine',
    description: 'Save 3 ideas in the Idea Lab.',
    icon: Icons.tips_and_updates_rounded,
    isUnlocked: (s) => s.ideas >= 3,
  ),
  Achievement(
    id: 'idea_advanced',
    title: 'Beyond the Napkin',
    description: 'Move an idea to Validating, Building, or Launched.',
    icon: Icons.rocket_launch_rounded,
    isUnlocked: (s) => s.ideasAdvanced >= 1,
  ),
  Achievement(
    id: 'quiz_1',
    title: 'Quiz Taker',
    description: 'Pass your first module quiz.',
    icon: Icons.quiz_rounded,
    isUnlocked: (s) => s.quizzesPassed >= 1,
  ),
  Achievement(
    id: 'quiz_perfect',
    title: 'Perfect Score',
    description: 'Score 100 percent on a module quiz.',
    icon: Icons.stars_rounded,
    isUnlocked: (s) => s.perfectQuizzes >= 1,
  ),
];

Future<AchievementStats> loadAchievementStats() async {
  final db = ProgressDb.instance;
  final completed = await db.getCompletedLessonIds();
  final ideas = await db.getIdeas();
  final streak = await db.getCurrentStreak();
  final longest = await db.getLongestStreak();
  final challenges = await db.getCompletedChallengeCount();
  final quizScores = await db.getQuizScores();
  final quizzesPassed = quizScores.values.where((v) => v[1] > 0 && v[0] * 2 >= v[1]).length;
  final perfectQuizzes = quizScores.values.where((v) => v[1] > 0 && v[0] == v[1]).length;

  int totalLessons = 0;
  int modulesDone = 0;
  int lessonsDone = 0;
  for (final m in modulesCatalog) {
    totalLessons += m.lessons.length;
    final doneHere = m.lessons.where((l) => completed.contains(l.id)).length;
    lessonsDone += doneHere;
    if (m.lessons.isNotEmpty && doneHere == m.lessons.length) {
      modulesDone++;
    }
  }

  const advanced = {'Validating', 'Building', 'Launched'};
  final ideasAdvanced = ideas.where((i) => advanced.contains(i.status)).length;

  return AchievementStats(
    lessonsDone: lessonsDone,
    totalLessons: totalLessons,
    modulesDone: modulesDone,
    totalModules: modulesCatalog.length,
    streak: streak,
    longestStreak: longest,
    challenges: challenges,
    ideas: ideas.length,
    ideasAdvanced: ideasAdvanced,
    quizzesPassed: quizzesPassed,
    perfectQuizzes: perfectQuizzes,
  );
}
