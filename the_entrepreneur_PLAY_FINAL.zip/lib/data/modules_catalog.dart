import '../models/module.dart';
import 'content/module_1.dart';
import 'content/module_2.dart';
import 'content/module_3.dart';
import 'content/module_4.dart';
import 'content/module_5.dart';
import 'content/module_6.dart';
import 'content/module_7.dart';
import 'content/module_8.dart';
import 'content/module_9.dart';
import 'content/module_10.dart';

// All modules are currently free (isFree: true) while the app grows its
// user base. The paywall plumbing (PurchaseService, PaywallScreen,
// ModuleNavigation.openModule) is untouched, so flipping any module back
// to isFree: false later is a one-line change per module, no other code
// needs to move.
final List<Module> modulesCatalog = [
  Module(
    id: 'spotting_opportunity',
    number: 1,
    title: 'Spotting Opportunity',
    description: 'Pattern recognition, unmet needs, and reading friction as signal.',
    colorValue: 0xFFD4537E,
    isFree: true,
    lessons: module1Lessons,
  ),
  Module(
    id: 'technology_wave',
    number: 2,
    title: 'The Technology Wave',
    description: 'AI, platforms, robotics, and industrial shifts, and how they compound.',
    colorValue: 0xFF378ADD,
    isFree: true,
    lessons: module2Lessons,
  ),
  Module(
    id: 'validating_idea',
    number: 3,
    title: 'Validating the Idea',
    description: 'Smoke tests, concierge MVPs, and knowing when to kill an idea.',
    colorValue: 0xFFEF9F27,
    isFree: true,
    lessons: module3Lessons,
  ),
  Module(
    id: 'building_product',
    number: 4,
    title: 'Building the Product',
    description: 'No-code to full-stack paths, and building fast with AI tools.',
    colorValue: 0xFF7F77DD,
    isFree: true,
    lessons: module4Lessons,
  ),
  Module(
    id: 'business_investment',
    number: 5,
    title: 'Business Model & Investment',
    description: 'Unit economics, pitching, and bootstrapping vs. raising.',
    colorValue: 0xFF1D9E75,
    isFree: true,
    lessons: module5Lessons,
  ),
  Module(
    id: 'go_to_market',
    number: 6,
    title: 'Go-to-Market',
    description: 'Positioning, first 100 customers, and distribution channels.',
    colorValue: 0xFFE24B4A,
    isFree: true,
    lessons: module6Lessons,
  ),
  Module(
    id: 'scaling_operations',
    number: 7,
    title: 'Scaling & Operations',
    description: 'Hiring, systems, culture, and when automation actually pays off.',
    colorValue: 0xFF534AB7,
    isFree: true,
    lessons: module7Lessons,
  ),
  Module(
    id: 'ai_native_products',
    number: 8,
    title: 'Building AI-Native Products',
    description: 'Beyond the wrapper: data loops, reliability, costs, and trust in AI products.',
    colorValue: 0xFF0F8B8D,
    isFree: true,
    lessons: module8Lessons,
  ),
  Module(
    id: 'global_emerging_markets',
    number: 9,
    title: 'Global and Emerging Markets',
    description: 'Leapfrogging, building for constraints, local trust, and serving the underserved.',
    colorValue: 0xFFB5651D,
    isFree: true,
    lessons: module9Lessons,
  ),
  Module(
    id: 'resilience_ethics',
    number: 10,
    title: 'Resilience, Pivots, and Ethics',
    description: 'Handling rejection, knowing when to pivot, and building trust that lasts.',
    colorValue: 0xFF8E3B46,
    isFree: true,
    lessons: module10Lessons,
  ),
];
