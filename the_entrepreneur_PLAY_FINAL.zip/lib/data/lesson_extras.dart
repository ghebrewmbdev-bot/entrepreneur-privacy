class LessonExtra {
  final String takeaway;
  final String tryThis;
  const LessonExtra(this.takeaway, this.tryThis);
}

// Extra teaching material per lesson id: a one-line takeaway and a small action.
const Map<String, LessonExtra> lessonExtras = {
  'm10_l1': LessonExtra(
    'Treat every no as information, then decide what to change and what to keep.',
    'Take your last rejection and write what it taught you in one sentence, plus one change you will make.',
  ),
  'm10_l2': LessonExtra(
    'Pivot on evidence, and carry your learning into the new direction.',
    'Write the one result that would convince you to pivot, with a date for checking it.',
  ),
  'm10_l3': LessonExtra(
    'Your product can end, but your core capability can move to a new market.',
    'List three skills your team or you have that could serve a completely different customer.',
  ),
  'm10_l4': LessonExtra(
    'Keep promises that protect your users, and your users become your strongest asset.',
    'Draft a three-line promise to your future customers about how you will treat them and their data.',
  ),
  'm1_l1': LessonExtra(
    'Your own daily frustrations are a free source of product ideas.',
    'Keep a friction log for three days: write every small annoyance with the time you noticed it.',
  ),
  'm1_l2': LessonExtra(
    'Timing is part of the idea. Ask what just became cheap enough to make this possible.',
    'List three costs that have dropped in the last five years and one new product each one enables.',
  ),
  'm1_l3': LessonExtra(
    'Leaders often ignore better technology to protect old profits. That is your opening.',
    'Pick one industry you know and write what its leader earns from the status quo.',
  ),
  'm1_l4': LessonExtra(
    'Talk to real people about their real past behavior before you build.',
    'Book three 15-minute conversations this week and ask each person about the last time they faced the problem.',
  ),
  'm1_l5': LessonExtra(
    'A narrow niche you serve deeply can grow into a large business.',
    'Describe your ideal first customer in one sentence so specific you could find them by name.',
  ),
  'm2_l1': LessonExtra(
    'Four big waves are happening at once, and their overlap creates the openings.',
    'Write one idea that combines two waves, such as AI plus a physical service.',
  ),
  'm2_l2': LessonExtra(
    'Platforms lower the cost of starting, so small teams can now compete with big ones.',
    'List the platforms your idea could launch on this month at almost no cost.',
  ),
  'm2_l3': LessonExtra(
    'Robots pay off where work is repetitive, physical, and high volume.',
    'Find one repetitive physical task near you and estimate how many hours it takes each week.',
  ),
  'm2_l4': LessonExtra(
    'New technology pays off only when you redesign the work around it.',
    'Pick a process at work or home and sketch how it would look if built from scratch around AI.',
  ),
  'm2_l5': LessonExtra(
    'Being early and being too early both cost money. Check the timing signals.',
    'Write three signs that the timing for your idea is right, and one sign it may be too early.',
  ),
  'm3_l1': LessonExtra(
    'A simple page that asks for a real action reveals true interest.',
    'Draft a one-page smoke test: headline, one promise, one button, and a number that counts as success.',
  ),
  'm3_l2': LessonExtra(
    'Do the service by hand first. You will learn what the product must do.',
    'Write the steps you would perform by hand for your first customer.',
  ),
  'm3_l3': LessonExtra(
    'Ask about past behavior, not future promises.',
    'Rewrite three of your interview questions so each asks about something that already happened.',
  ),
  'm3_l4': LessonExtra(
    'The strongest proof is someone paying before the product exists.',
    'Name the first five people you would ask to pre-order and what you would offer them.',
  ),
  'm3_l5': LessonExtra(
    'Killing a weak idea early is a win. It frees your time for a better one.',
    'Write the kill criteria for your idea: the number or result that means stop.',
  ),
  'm4_l1': LessonExtra(
    'Ship the smallest version that solves the core problem.',
    'Cut your feature list to the one job a user would pay for, and cross out everything else.',
  ),
  'm4_l2': LessonExtra(
    'No-code is a fast first draft to test demand, not a final system.',
    'List which parts of your idea could be built this weekend with no-code tools.',
  ),
  'm4_l3': LessonExtra(
    'AI speeds building, but you stay responsible for judgment, testing, and safety.',
    'Pick one small feature and write the exact instructions you would give an AI assistant to build it.',
  ),
  'm4_l4': LessonExtra(
    'Bring in a technical partner when the product needs skills you cannot rent or learn fast enough.',
    'Write the two skills your product needs that you lack, and who you could ask this month.',
  ),
  'm4_l5': LessonExtra(
    'Clear, honest, reliable design earns trust before beauty does.',
    'Look at your main screen and list three things a stranger might not trust about it.',
  ),
  'm5_l1': LessonExtra(
    'Know what it costs to serve a customer and what they pay, before you scale.',
    'Use the Calculators screen to compute your contribution per customer and your break-even point.',
  ),
  'm5_l2': LessonExtra(
    'Outside money is a choice with trade-offs, not a measure of success.',
    'Write what you would need to believe to justify raising money, and what bootstrapping would require instead.',
  ),
  'm5_l3': LessonExtra(
    'Investors look for a real problem, a growing signal, a capable team, and a large enough market.',
    'Write your pitch in four sentences: problem, solution, proof so far, and what you are asking for.',
  ),
  'm5_l4': LessonExtra(
    'Learn the basic terms of a deal before you are asked to sign one.',
    'Look up three terms in the Glossary, such as valuation, dilution, and liquidation preference, and restate each in your own words.',
  ),
  'm5_l5': LessonExtra(
    'Pre-orders, grants, revenue-based loans, and customers can also fund a company.',
    'List three non-equity ways your idea could be funded and the first step toward each.',
  ),
  'm6_l1': LessonExtra(
    'Own one clear word or promise in your customer\'s mind.',
    'Fill in the Positioning Statement in the Toolkit for your idea.',
  ),
  'm6_l2': LessonExtra(
    'Your first 100 customers come from direct, personal effort.',
    'Write the names or groups of 20 people who could be your first customers and where you would find them.',
  ),
  'm6_l3': LessonExtra(
    'Pick one distribution channel and go deep before trying many.',
    'Choose one channel to test for two weeks and write the number that would count as a success.',
  ),
  'm6_l4': LessonExtra(
    'Price tells customers what kind of product this is.',
    'Write three possible prices and who each would attract.',
  ),
  'm6_l5': LessonExtra(
    'Keeping customers is cheaper and stronger than finding new ones.',
    'Write the moment a new user first gets value, and how you could get them there faster.',
  ),
  'm7_l1': LessonExtra(
    'Hire for the problem you have now, and define the outcome the person owns.',
    'Write one measurable outcome your next hire would own in their first 90 days.',
  ),
  'm7_l2': LessonExtra(
    'Add systems when pain appears, and not before.',
    'List the one task you repeat most often and write down its steps so someone else could do it.',
  ),
  'm7_l3': LessonExtra(
    'Automate a process only after you have made it work well by hand.',
    'Time one repetitive process and decide whether automating it would pay for itself within a year.',
  ),
  'm7_l4': LessonExtra(
    'Culture is the behavior you repeat and reward, not the poster on the wall.',
    'Write one value and a hard decision where it would cost you something.',
  ),
  'm7_l5': LessonExtra(
    'Saying no to growth that does not fit protects what makes you good.',
    'Write one type of customer or feature request you will decline, and why.',
  ),
  'm8_l1': LessonExtra(
    'The model is a commodity. The workflow, data, and trust around it are the product.',
    'Write down three things your idea owns that a competitor with the same AI model could not copy in a month.',
  ),
  'm8_l2': LessonExtra(
    'The best advantage is a product that gets better every time someone uses it.',
    'Sketch one feedback moment in your product, such as a thumbs up or an edit, and what you would learn from it.',
  ),
  'm8_l3': LessonExtra(
    'Trust is built by testing, labeling, and making errors cheap to catch.',
    'List ten real examples your AI feature must get right, with the correct answer for each. That is your first test set.',
  ),
  'm8_l4': LessonExtra(
    'Know what one use of your AI feature costs before you promise unlimited anything.',
    'Open the Calculators screen and enter your best guess of cost per user per month against the price you would charge.',
  ),
  'm9_l1': LessonExtra(
    'Missing infrastructure is an opening, not a barrier.',
    'Name one service people near you still do in person or on paper that a phone could handle.',
  ),
  'm9_l2': LessonExtra(
    'Design for the hardest conditions and the product works everywhere.',
    'Turn off your wifi and try to do the main job of your idea on mobile data only. Note where it fails.',
  ),
  'm9_l3': LessonExtra(
    'In new markets, trust and local habits beat size and brand.',
    'Interview one person from your target market about the last time they hesitated to pay online and why.',
  ),
  'm9_l4': LessonExtra(
    'Serving people with less money is a design challenge, and a durable business can meet it.',
    'Write one sentence that states what a customer with a very small budget gains from your product each month.',
  ),
};
