import '../../models/module.dart';

final List<Lesson> module8Lessons = [
  const Lesson(
    id: 'm8_l1',
    title: 'Wrapper or Moat?',
    principle:
        'Anyone can connect to a powerful AI model. A product becomes defensible when it owns something the model alone cannot give: a workflow people depend on, proprietary data, distribution, or deep trust in one narrow job.',
    story:
        'Picture two apps that both summarize meetings with the same AI model. One is a thin screen that pastes in a transcript. The other lives inside the team calendar, assigns follow-up tasks, remembers past decisions, and fits how that team already works. When the underlying model gets cheaper or a bigger company copies the summary feature, only the second app still has a reason to exist. This is an illustrative scenario, not a specific company.',
    bestPractices: [
      'Ask what happens to your product the day a competitor gets access to the exact same AI model',
      'Build around a workflow the customer repeats daily, not a one-time trick',
      'Aim for one narrow job done reliably rather than a broad assistant that does everything loosely',
    ],
    reflection: 'If the AI model behind your idea became free and universal tomorrow, what would still make people choose your product?',
  ),
  const Lesson(
    id: 'm8_l2',
    title: 'Data Loops That Compound',
    principle:
        'A data loop means every use of the product makes the next use better. Corrections, choices, and outcomes from real users are a quiet advantage that grows with time and is hard to buy.',
    story:
        'Netflix built its business on a loop: the more people watched and rated, the better its recommendations became, which kept people watching. Its early DVD-by-mail service already collected what members queued and returned, years before streaming existed. The behavior data became a lasting asset, not just a feature.',
    bestPractices: [
      'Design the product so normal use produces useful feedback, such as accepting, editing, or rejecting a suggestion',
      'Decide early what you are allowed to store and say it plainly to users',
      'Measure whether quality actually improves as data grows, not just whether the data pile grows',
    ],
    reflection: 'What signal does a user produce just by using your product that could make it smarter for the next user?',
  ),
  const Lesson(
    id: 'm8_l3',
    title: 'Reliability, Evaluation, and Honest Limits',
    principle:
        'AI output can be fluent and still wrong. Trustworthy products test their AI on real examples before shipping, show uncertainty, keep a human in the loop for high-stakes steps, and make mistakes easy to catch and fix.',
    story:
        'Imagine an AI tool that drafts replies to customer complaints. The team keeps a folder of 100 real past complaints with the replies a senior agent approved. Before every change, they run the tool on that folder and compare. When a new setting makes answers sound friendlier but promise refunds the company does not offer, the test catches it before any customer does. This is an illustrative scenario.',
    bestPractices: [
      'Build a small test set from real cases before launch and rerun it after every change',
      'Label AI-generated content clearly and let users correct it in one tap',
      'Require human approval for anything involving money, health, safety, or legal commitments',
    ],
    reflection: 'Which mistake from your AI would hurt a user most, and what would stop it from reaching them?',
  ),
  const Lesson(
    id: 'm8_l4',
    title: 'The Economics of AI Features',
    principle:
        'Unlike most software, AI features can carry a real cost every time they are used. Price, limits, and design choices must be set so heavy users do not quietly turn a profitable product into a loss.',
    story:
        'Picture a writing app that includes unlimited AI help for a flat monthly fee. A small group of power users generate hundreds of requests a day, and the cost of serving them exceeds what they pay. The team fixes it with fair usage limits, a cheaper model for simple tasks, and a higher tier for heavy use. This is an illustrative scenario.',
    bestPractices: [
      'Estimate cost per request and requests per active user before setting your price',
      'Use a smaller, cheaper model for easy tasks and save the expensive one for hard ones',
      'Watch your heaviest 5 percent of users, since they often decide your margin',
    ],
    reflection: 'If your most active user doubled their usage, would your business get stronger or weaker?',
  ),
];
