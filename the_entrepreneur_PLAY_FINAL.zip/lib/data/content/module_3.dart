import '../../models/module.dart';

final List<Lesson> module3Lessons = [
  const Lesson(
    id: 'm3_l1',
    title: 'The Smoke Test',
    principle:
        'You can validate demand before building anything by measuring whether people take a real action in response to your idea, not whether they say they like it.',
    story:
        'Zappos founder Nick Swinmurn tested online shoe sales in 1999 by photographing shoes at a local store, posting them online, then buying the shoes himself at full price when someone ordered. No inventory, no warehouse, just proof people would buy shoes online. That proof became a company later sold to Amazon for 1.2 billion dollars.',
    bestPractices: [
      'Build the smallest possible front door before the product',
      'Measure real commitment, a pre-payment is far stronger signal than an email address',
      'Kill ideas quickly if nobody takes real action, this is a feature of the process, not a failure',
    ],
    reflection: 'What is the smallest test you could run this week to see if people want your idea?',
  ),
  const Lesson(
    id: 'm3_l2',
    title: 'The Concierge MVP',
    principle:
        'Before automating anything, manually deliver the outcome to a handful of customers yourself. This teaches you exactly what the product needs to do.',
    story:
        'Before building any software, the founders of Food on the Table, an Austin meal-planning startup, are often cited as building meal plans by hand for their first customers, acting as a human version of the product before building software.',
    bestPractices: [
      'Deliver the result manually before writing code',
      'Charge money even for the manual version, it is the strongest validation signal there is',
      'Only build automation for the specific steps manual delivery proved were the bottleneck',
    ],
    reflection: 'Could you deliver your idea\'s outcome by hand to 3 people this month, with no software at all?',
  ),
  const Lesson(
    id: 'm3_l3',
    title: 'Talking to Users Without Leading Them',
    principle:
        'Most founders unconsciously ask questions that confirm what they already believe. Good validation interviews focus on past behavior, not future hypotheticals.',
    story:
        'A widely used interview framework warns against questions like would you use an app that does X, almost everyone says yes to be polite. Instead ask tell me about the last time you dealt with this, and what have you already tried.',
    bestPractices: [
      'Avoid pitching your idea in the first half of any customer conversation',
      'Ask about specific past instances, not hypothetical futures',
      'Watch for what they have already spent money or serious effort trying, that is the real signal',
    ],
    reflection: 'Rewrite one question you would ask a potential customer to focus on their past behavior instead of a hypothetical.',
  ),
  const Lesson(
    id: 'm3_l4',
    title: 'Pre-Selling Before Building',
    principle:
        'Getting a customer to pay before the product exists is the strongest possible validation. It proves both desire and willingness to pay.',
    story:
        'Dropbox\'s founder Drew Houston, unable to build a working demo fast enough, made a simple screen-recording video showing how the product would work. The video drove the beta waitlist from 5,000 to 75,000 overnight, proving overwhelming demand before a real product existed.',
    bestPractices: [
      'A demo video or mockup can substitute for a finished product when testing demand',
      'Offer a real, refundable pre-order or deposit, interested and willing to pay now are very different signals',
      'Track conversion rate from interest to payment as your core validation metric',
    ],
    reflection: 'Could you create a simple video or mockup this week that shows your idea working, even if it does not yet?',
  ),
  const Lesson(
    id: 'm3_l5',
    title: 'When to Kill an Idea',
    principle:
        'Persistence is only a virtue when the underlying assumption is still plausible. Knowing when to walk away is as much a skill as knowing when to push through.',
    story:
        'The founders behind Slack originally spent years building a video game called Glitch, which failed to gain traction and was shut down. An internal messaging tool they had built for their own team became the actual product, later valued at over 27 billion dollars.',
    bestPractices: [
      'Set a specific, measurable signal in advance for this is not working',
      'Distinguish the idea is wrong from the execution needs to change',
      'Look inside a failing idea for a smaller, real insight worth keeping',
    ],
    reflection: 'What would have to be true for you to decide an idea is not working, and by when would you check?',
  ),
];
