import '../../models/module.dart';

final List<Lesson> module10Lessons = [
  const Lesson(
    id: 'm10_l1',
    title: 'Rejection Is Data, Not a Verdict',
    principle:
        'Almost every founder hears no far more than yes. The skill is separating a no that reveals a flaw in the idea from a no that only reveals a mismatch with that listener.',
    story:
        'Jack Ma has said he applied for about 30 jobs and was turned down for all of them, including a KFC opening in his city. Melanie Perkins and Cliff Obrecht were rejected by more than 100 investors in 2013 while seeking funding for what became Canva. Both kept going, but both also changed what they were doing as they learned from the nos.',
    bestPractices: [
      'After each rejection, write down the exact reason given and look for patterns across several',
      'Change one thing at a time between pitches so you learn what matters',
      'Keep a small circle of people who will tell you honestly when an idea needs to change',
    ],
    reflection: 'What is the most useful no you have received, and what did it teach you?',
  ),
  const Lesson(
    id: 'm10_l2',
    title: 'When to Pivot and When to Persist',
    principle:
        'A pivot is a change of direction based on what you learned, not a sign of failure. Persist when the problem is real and your approach is improving, pivot when the evidence keeps pointing somewhere else.',
    story:
        'Evan Williams co-founded Blogger, which Google bought in 2003, then started the podcasting company Odeo. In 2006 he, Jack Dorsey, and Biz Stone built a prototype of a short-message service, and Twitter launched that year. In 2007 their company Obvious acquired Odeo and spun Twitter off as its own company. A side experiment inside a struggling company became the main event.',
    bestPractices: [
      'Set a clear checkpoint, such as 90 days, and decide beforehand what results mean continue or change',
      'Pay attention to what users do on their own that you did not plan for',
      'Keep what you learned and what you built when you pivot, instead of starting from zero',
    ],
    reflection: 'What evidence would make you change direction, and have you already seen some of it?',
  ),
  const Lesson(
    id: 'm10_l3',
    title: 'Reinventing a Core Business',
    principle:
        'The hardest pivot is changing a business that still makes money today. Survivors ask what their real strength is beneath the product, then apply it to new markets before the old one collapses.',
    story:
        'Kodak invented a digital camera concept in 1975 but kept protecting its film profits, and filed for Chapter 11 bankruptcy on January 19, 2012. Fujifilm faced the same collapse of film, and under president Shigetaka Komori it asked what it was truly good at. It named chemistry, optics, and nanotechnology, launched a restructuring plan in 2004, and moved into healthcare, cosmetics, and other fields. By the year to March 2026 healthcare made up just under a third of its revenue.',
    bestPractices: [
      'Describe your company by what it can do, not the single product it sells today',
      'Start new lines while the old business still pays for the experiments',
      'Be willing to cut what no longer fits, even if it was once the pride of the company',
    ],
    reflection: 'Beneath the product you sell today, what is the underlying skill someone would pay for in another market?',
  ),
  const Lesson(
    id: 'm10_l4',
    title: 'Trust and Ethics as a Growth Strategy',
    principle:
        'Shortcuts that harm users can pay off for a while, then collapse the business. Clear promises about privacy, honesty, and fair treatment are not just right, they are among the strongest long-term advantages a company can hold.',
    story:
        'Jan Koum and co-founder Brian Acton built WhatsApp around a short list of promises, including no ads. After Facebook acquired WhatsApp in 2014 for about 19 billion dollars, Koum left the company in 2018, reportedly over disagreements about privacy and advertising plans. Whatever one thinks of the outcome, the story shows that founders who state their values early can be held to them, by users and by themselves.',
    bestPractices: [
      'Write down three promises you will not break, even when a growth hack tempts you',
      'Collect only the data you truly need and explain in plain words why',
      'Make it easy for users to leave, export their data, and understand what they agreed to',
    ],
    reflection: 'What is one thing a competitor might do for growth that you would refuse to do?',
  ),
];
