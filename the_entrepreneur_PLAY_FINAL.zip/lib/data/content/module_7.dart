import '../../models/module.dart';

final List<Lesson> module7Lessons = [
  const Lesson(
    id: 'm7_l1',
    title: 'Hiring for the Stage You Are At',
    principle:
        'Early-stage hires need to be generalists comfortable with ambiguity, later-stage hires need specialists who can go deep in one function.',
    story:
        'Early Google employees wore many hats, engineers doing support, marketers doing data analysis, because the company was still figuring out what it needed. As Google scaled into the thousands, specialized roles became essential.',
    bestPractices: [
      'In the earliest stage, hire for adaptability and shared conviction over narrow expertise',
      'As you scale, define roles clearly and hire specialists who can operate independently',
      'Avoid hiring too far ahead of your actual current needs',
    ],
    reflection: 'Is your current stage calling for a generalist or a specialist?',
  ),
  const Lesson(
    id: 'm7_l2',
    title: 'Systems Before You Need Them, But Not Too Early',
    principle:
        'Building process too early adds bureaucracy to a company that has not found its product yet. Building it too late means growth breaks the company from the inside.',
    story:
        'Startups that scale headcount rapidly without matching systems often experience growing pains, where the same team that thrived at 10 people struggles badly at 50, not because people got worse, but because coordination broke down.',
    bestPractices: [
      'Add lightweight process only when the absence of it is visibly causing real problems',
      'Document decisions and processes as you make them',
      'Revisit your systems at every major growth milestone',
    ],
    reflection: 'What is one recurring point of confusion in how you currently operate that a simple system could fix?',
  ),
  const Lesson(
    id: 'm7_l3',
    title: 'When Automation and Robotics Actually Pay Off',
    principle:
        'Automation makes sense when a task is repetitive, high-volume, and consistent, not simply because the technology exists.',
    story:
        'Amazon automated warehouse picking with robots only after years of refining the underlying process with human workers, ensuring the workflow itself was efficient before layering automation on top.',
    bestPractices: [
      'Fix and stabilize a process manually before automating it',
      'Automate first where volume is highest and the task is most repetitive',
      'Calculate the real payback period, including maintenance and error-handling costs',
    ],
    reflection: 'What is one task in your operation that is both high-volume and highly repetitive?',
  ),
  const Lesson(
    id: 'm7_l4',
    title: 'Culture Is What You Repeat, Not What You Write Down',
    principle:
        'A mission statement on a wall means nothing if daily decisions contradict it. Culture is built through consistent, repeated choices, especially under pressure.',
    story:
        'Netflix\'s culture document emphasizes freedom and responsibility, but the real culture was built by specific decisions, like removing expense-approval processes and trusting employees, reinforced consistently over years.',
    bestPractices: [
      'Identify the hard tradeoffs your company faces regularly and check your choices match your stated values',
      'Reinforce desired behavior visibly through what gets praised, promoted, and funded',
      'Revisit culture explicitly as the team grows, since unstated norms do not transfer automatically',
    ],
    reflection: 'What is one hard decision you have made recently that either reinforced or contradicted the culture you want?',
  ),
  const Lesson(
    id: 'm7_l5',
    title: 'Knowing When to Say No to Growth',
    principle:
        'Not every growth opportunity is worth pursuing. Saying yes to the wrong customers, markets, or features can dilute focus and damage what made the company work.',
    story:
        'Basecamp has repeatedly turned down opportunities to add features or chase enterprise customers that did not fit its core focus, prioritizing a smaller, well-served customer base over diluted growth.',
    bestPractices: [
      'Define explicitly what kind of customer or opportunity you will say no to, in advance',
      'Evaluate growth opportunities against your core focus, not just revenue potential',
      'Revisit past no decisions periodically, since the right answer can change as the company matures',
    ],
    reflection: 'What is one type of opportunity you should probably say no to right now, even though it is tempting?',
  ),
];
