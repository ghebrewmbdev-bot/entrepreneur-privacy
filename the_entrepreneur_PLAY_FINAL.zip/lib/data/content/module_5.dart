import '../../models/module.dart';

final List<Lesson> module5Lessons = [
  const Lesson(
    id: 'm5_l1',
    title: 'Know Your Unit Economics Before You Scale',
    principle:
        'A business only works if it makes more from a customer than it costs to acquire and serve them. Scaling before this math works simply loses money faster.',
    story:
        'Many food-delivery startups in the 2010s scaled aggressively while losing money on every order, betting scale would fix the economics. Several shut down or were acquired at steep losses once investors stopped subsidizing the gap.',
    bestPractices: [
      'Calculate customer acquisition cost and customer lifetime value before spending on growth',
      'If unit economics do not work at small scale, they rarely fix themselves at large scale',
      'Treat we will figure out monetization later as a warning sign, not a strategy',
    ],
    reflection: 'If you got one customer today, would you make more from them over time than it cost to get them?',
  ),
  const Lesson(
    id: 'm5_l2',
    title: 'Bootstrapping vs. Raising Capital',
    principle:
        'Neither path is inherently better. Bootstrapping keeps control and forces discipline, raising capital buys speed at the cost of ownership.',
    story:
        'Basecamp bootstrapped from day one, stayed profitable, and never took outside funding, building a lasting, founder-controlled business over two decades. Companies chasing genuinely capital-intensive, winner-take-most markets often need venture funding just to compete.',
    bestPractices: [
      'Ask if your opportunity requires speed and scale to defend against competitors, or can grow steadily',
      'Bootstrapping means real revenue from real customers early, not living on savings indefinitely',
      'Raising capital means trading ownership and control for speed, know exactly what you are trading',
    ],
    reflection: 'Does your idea need to move fast to beat competitors to a market, or can it grow steadily on its own revenue?',
  ),
  const Lesson(
    id: 'm5_l3',
    title: 'What Investors Actually Look For',
    principle:
        'Investors are betting on market size, team strength, and evidence you can learn and adapt faster than competitors, not just your current product.',
    story:
        'Several investors passed on Airbnb in its early days, doubting strangers would ever stay in each other\'s homes. What eventually changed their minds was real usage data proving the behavior was already happening at growing scale.',
    bestPractices: [
      'Lead a pitch with evidence of real demand, not just vision',
      'Be able to explain specifically why now is the right time for this idea',
      'Expect rejection as the norm, and treat each no as a chance to sharpen your evidence',
    ],
    reflection: 'What real evidence do you currently have, or could gather this month, that people want what you are building?',
  ),
  const Lesson(
    id: 'm5_l4',
    title: 'Reading a Term Sheet, Simply',
    principle:
        'You do not need a law degree to understand the core terms that matter most: how much of the company you are giving up, what control you are giving up, and what happens if things go wrong.',
    story:
        'Founders who skip understanding basic terms like valuation and liquidation preference often discover too late how much control or upside they signed away, since these terms compound in ways that are not obvious at signing.',
    bestPractices: [
      'Understand valuation and how much of the company you are selling at that price',
      'Know what board seats and voting rights you are giving away',
      'Always have a lawyer review real terms, this is orientation, not legal advice',
    ],
    reflection: 'Which key terms (equity, dilution, liquidation preference, vesting, SAFE) are you least familiar with?',
  ),
  const Lesson(
    id: 'm5_l5',
    title: 'Alternative Funding Paths',
    principle:
        'Venture capital is one funding path among many. Grants, revenue-based financing, crowdfunding, and strategic partnerships can fund a business without giving up equity or control.',
    story:
        'The Pebble smartwatch raised over 10 million dollars through Kickstarter in 2012, funding manufacturing directly from customer pre-orders rather than venture capital, proving demand and securing capital in the same move.',
    bestPractices: [
      'Consider crowdfunding when you have a tangible product people can pre-order and get excited about',
      'Research government and industry grants relevant to your sector',
      'Revenue-based financing lets you borrow against future revenue without giving up equity',
    ],
    reflection: 'Is there a funding path other than venture capital that fits your idea better?',
  ),
];
