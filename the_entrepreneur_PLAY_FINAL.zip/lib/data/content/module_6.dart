import '../../models/module.dart';

final List<Lesson> module6Lessons = [
  const Lesson(
    id: 'm6_l1',
    title: 'Positioning: Own One Word in Someone\'s Mind',
    principle:
        'Trying to be everything to everyone means being memorable to no one. Strong positioning claims one clear space in the customer\'s mind.',
    story:
        'Volvo has owned the word safety in car buyers\' minds for decades, even though many competitors\' cars are equally safe by modern standards. That single-word ownership shapes buying decisions before a customer compares specs.',
    bestPractices: [
      'Write your positioning as one sentence naming the customer, need, category, and key differentiator',
      'Choose one differentiator to be known for rather than listing every feature',
      'Check your chosen position is not already firmly owned by a competitor',
    ],
    reflection: 'If your product could own one word in your customer\'s mind, what would it be?',
  ),
  const Lesson(
    id: 'm6_l2',
    title: 'Finding Your First 100 Customers',
    principle:
        'Early customers rarely come from broad marketing, they come from direct, often unscalable effort: personal networks, communities, and manual outreach.',
    story:
        'Before Airbnb had a marketing budget, its founders personally went door to door in New York meeting hosts, and built a way to cross-post listings to Craigslist, borrowing another platform\'s audience.',
    bestPractices: [
      'Go where your exact customer already spends time rather than building your own audience from zero',
      'Do things that do not scale at first: personal outreach, manual onboarding, direct conversations',
      'Ask your first customers directly who else has this problem',
    ],
    reflection: 'Where does your ideal first customer already spend time online or offline?',
  ),
  const Lesson(
    id: 'm6_l3',
    title: 'Distribution Channels Unique to Tech Products',
    principle:
        'Digital products have distribution advantages physical products do not: virality built into the product itself, app store discovery, and platform algorithms.',
    story:
        'Dropbox\'s referral program, giving both the referrer and new user extra storage, drove a 60 percent permanent increase in signups, turning existing users into a free acquisition channel built into the product.',
    bestPractices: [
      'Look for a way to build sharing or invitation into the product\'s core use',
      'Study app store or platform algorithm mechanics if distributing through one',
      'Track which channel brings your best, not just most, customers',
    ],
    reflection: 'Could your product naturally create a reason for one user to invite another?',
  ),
  const Lesson(
    id: 'm6_l4',
    title: 'Pricing as a Positioning Decision',
    principle:
        'Price signals quality, target customer, and market position, not just cost coverage. Underpricing can hurt trust and margins as much as overpricing kills demand.',
    story:
        'Superhuman, an email app, deliberately priced at 30 dollars a month when competitors were free, using price itself to signal a premium product and filter for customers who valued speed enough to pay for it.',
    bestPractices: [
      'Price based on value delivered and the customer segment you want, not just your costs',
      'Test a few price points with real customers before locking in a permanent price',
      'Raising prices later is much harder than lowering them, when in doubt start slightly higher',
    ],
    reflection: 'Does your planned price signal the position you want in customers\' minds?',
  ),
  const Lesson(
    id: 'm6_l5',
    title: 'Retention Beats Acquisition',
    principle:
        'A leaky bucket cannot be filled by pouring in more water. If customers do not stick around, no amount of new acquisition fixes the underlying problem.',
    story:
        'Many early social apps achieved huge download numbers through viral marketing but failed because users did not return after their first session. Products like Instagram and Slack focused early on daily and weekly active use, not just downloads.',
    bestPractices: [
      'Track how many users come back a week after signing up, not just total signups',
      'Talk to users who stopped using your product to understand exactly why',
      'Fix retention before scaling acquisition spend, since growth amplifies a leaky product\'s losses',
    ],
    reflection: 'If you launched today, what would make someone come back a second time?',
  ),
];
