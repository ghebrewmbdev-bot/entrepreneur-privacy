import '../../models/module.dart';

final List<Lesson> module9Lessons = [
  const Lesson(
    id: 'm9_l1',
    title: 'Leapfrogging: Skipping a Whole Stage',
    principle:
        'Where old infrastructure never arrived, people can jump straight to the newest solution. The biggest opportunities often appear where the current system is missing, not where it is slightly flawed.',
    story:
        'M-Pesa was piloted in Kenya in 2005 and launched commercially in 2007 by Safaricom and Vodafone, with early support from a UK government challenge fund. It began as a way to receive and repay microfinance loans, then grew into a way for ordinary people to send money by phone. The name combines M for mobile with pesa, the Swahili word for money. Millions of people without bank accounts gained a payment system through a basic phone.',
    bestPractices: [
      'Look for places where a basic service is missing or very expensive, not just unpopular',
      'Build for the devices and connections people actually have today',
      'Watch how users bend your product to a new use, then lean into it',
    ],
    reflection: 'What everyday service in your region is slow, costly, or missing, and what has become cheap enough to solve it?',
  ),
  const Lesson(
    id: 'm9_l2',
    title: 'Building for Constraints',
    principle:
        'Low bandwidth, cheap phones, irregular power, and tight budgets are design inputs, not excuses. Products built to work under constraints are often faster, simpler, and cheaper everywhere.',
    story:
        'Strive Masiyiwa trained as an engineer and founded an engineering company in Zimbabwe in 1988 after working at the state telecom body. When he proposed a mobile network, the state monopoly refused to partner and the government denied him a licence. He fought through the courts for about five years and finally won, and Econet Wireless Zimbabwe launched in June 1998. He built a mobile company in a place where the rules and infrastructure were stacked against him.',
    bestPractices: [
      'Test your product on the slowest phone and weakest connection your customers have',
      'Make the core job work offline or with minimal data, then add extras',
      'Price for local incomes instead of copying prices from richer markets',
    ],
    reflection: 'Which assumption in your product would break on a cheap phone with a weak connection?',
  ),
  const Lesson(
    id: 'm9_l3',
    title: 'Winning Local Trust',
    principle:
        'Global giants lose where they treat a market as a copy of home. Local payment habits, language, and trust between buyers and sellers decide who wins, and locals often understand them best.',
    story:
        'When eBay moved into China, a Chinese challenger named Taobao, backed by Alibaba founded by Jack Ma, grew quickly and eBay offered to buy it. Ma refused, and Alibaba secured a large investment led by Yahoo co-founder Jerry Yang. Taobao and Alipay were built around how Chinese buyers and sellers needed to build trust. Local understanding beat a bigger foreign brand.',
    bestPractices: [
      'Spend time with local buyers and sellers before you copy a model that worked elsewhere',
      'Solve the trust problem first, such as payment protection or verified sellers',
      'Partner with locals who understand rules, language, and habits you do not',
    ],
    reflection: 'In the market you want to serve, what makes a stranger trustworthy enough to pay?',
  ),
  const Lesson(
    id: 'm9_l4',
    title: 'Serving the Underserved Sustainably',
    principle:
        'People with little money are customers with real needs, not a charity case. Products that charge fairly, fit their lives, and are built to last can serve them and still sustain themselves.',
    story:
        'In 1976, economist Muhammad Yunus lent small amounts of his own money to villagers near Jobra in Bangladesh, and watched them repay. That experiment grew into Grameen Bank, which became known for small loans to people who had no access to ordinary banks. Yunus and the bank received the Nobel Peace Prize in 2006. The lesson many founders draw is that small, trust-based lending can work when it fits borrowers real lives.',
    bestPractices: [
      'Start with a small pilot and watch real usage before scaling a model',
      'Charge a fair price so the service can survive instead of depending on goodwill',
      'Measure results for customers, such as time saved or income earned, not only your revenue',
    ],
    reflection: 'Who in your community is poorly served, and what would a fair, sustainable offer for them look like?',
  ),
];
