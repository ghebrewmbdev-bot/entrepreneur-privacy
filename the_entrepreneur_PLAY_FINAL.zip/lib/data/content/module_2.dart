import '../../models/module.dart';

final List<Lesson> module2Lessons = [
  const Lesson(
    id: 'm2_l1',
    title: 'Four Waves You Are Living Through',
    principle:
        'AI, the internet and platform economy, robotics, and the ongoing industrial shift toward automation are not separate trends, they compound. Understanding each gives you more surface area to find an opening.',
    story:
        'ChatGPT is estimated to have reached 100 million users within about two months of launch in early 2023, one of the fastest adoption curves ever recorded for a consumer product. That speed reflected an existing internet and mobile distribution layer built over 20 years, suddenly combined with a new capability.',
    bestPractices: [
      'Study each wave separately: what changed in AI, in distribution, in hardware and robotics',
      'Look for combinations, most breakout products stack two waves together',
      'Revisit old, abandoned ideas, many failed only because one piece of the stack was not ready',
    ],
    reflection: 'Name one old idea that failed years ago that might work now because of AI or cheaper hardware.',
  ),
  const Lesson(
    id: 'm2_l2',
    title: 'Platforms Change Who Can Compete',
    principle:
        'Internet platforms collapsed the cost of starting a company from millions of dollars to nearly zero. The constraint shifted from capital to insight and execution speed.',
    story:
        'In 1999, launching an online store required building your own servers, payment processing, and security, a six-figure investment. Today, one person can launch a Shopify store, accept payments via Stripe, and reach customers via Instagram ads before lunch.',
    bestPractices: [
      'Use existing infrastructure instead of building from scratch',
      'Spend your scarce time on what is actually unique to your idea, not on solved problems',
      'Remember low barriers to entry also mean low barriers for competitors, speed and insight matter more than ever',
    ],
    reflection: 'What parts of your idea could you build using existing tools instead of from scratch?',
  ),
  const Lesson(
    id: 'm2_l3',
    title: 'Robotics and the Physical World',
    principle:
        'While software ate the digital world, robotics and automation are doing the same to physical labor. Opportunities exist wherever physical work is repetitive, dangerous, or in short supply.',
    story:
        'Amazon acquired Kiva Systems in 2012 for 775 million dollars to automate warehouse picking with robots. By 2023, Amazon operated over 750,000 robots across its warehouse network, cutting fulfillment costs while handling far more volume.',
    bestPractices: [
      'Look for physical, repetitive tasks facing labor shortages',
      'You do not need to build robots yourself, software that makes existing automation smarter is often the bigger opportunity',
      'Consider industries slow to modernize such as agriculture, construction, and eldercare, less competition, real need',
    ],
    reflection: 'What physical, repetitive task in an industry you know is still done by hand?',
  ),
  const Lesson(
    id: 'm2_l4',
    title: 'The Industrial Revolution Playbook, Replayed',
    principle:
        'Every industrial revolution follows a pattern: a new capability emerges, early adopters gain outsized advantage, and eventually the whole economy restructures around it. AI is following the same arc as steam, electricity, and computing.',
    story:
        'When electricity first reached factories, most simply replaced their steam engine with an electric motor in the same spot and saw almost no productivity gain. Real gains came decades later, once factories were redesigned around distributed electric motors on each machine.',
    bestPractices: [
      'Do not just bolt AI onto an old process, ask what the process would look like redesigned from scratch',
      'Study previous industrial shifts for patterns that repeat',
      'Expect the biggest winners to emerge years after the initial hype, once redesign, not just adoption, happens',
    ],
    reflection: 'What is one process in your industry that has just had AI bolted on rather than being redesigned around it?',
  ),
  const Lesson(
    id: 'm2_l5',
    title: 'Betting on Trends vs. Riding Them Too Late',
    principle:
        'There is a narrow window between too early, where infrastructure and customers are not ready, and too late, where the market is saturated. Reading where a wave actually is matters as much as believing in it.',
    story:
        'Color TV took decades from first demonstration to mainstream adoption because of cost and infrastructure. Smartphone apps went from novelty to essential in under 5 years once app stores and fast mobile networks existed.',
    bestPractices: [
      'Ask what is still missing for mass adoption: cost, trust, regulation, infrastructure',
      'Look at adoption curves in adjacent markets as a signal for timing',
      'It is fine to build too early as a side project while you wait for the wave to be ready',
    ],
    reflection: 'Is the trend you are excited about missing any key piece of infrastructure or trust right now?',
  ),
];
