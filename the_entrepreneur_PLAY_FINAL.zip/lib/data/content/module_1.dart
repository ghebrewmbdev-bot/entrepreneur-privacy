import '../../models/module.dart';

final List<Lesson> module1Lessons = [
  const Lesson(
    id: 'm1_l1',
    title: 'Problems Hiding in Plain Sight',
    principle:
        'Every product started as someone\'s annoyance. Opportunity recognition is a habit: asking why does this still work this badly about ordinary friction.',
    story:
        'In 2007, Brian Chesky and Joe Gebbia could not afford rent in San Francisco. A design conference nearby was sold out of hotel rooms, so they inflated air mattresses on their floor and charged guests to stay. That annoyance became Airbnb.',
    bestPractices: [
      'Keep a running friction log of anything that took longer, cost more, or felt clunkier than it should have',
      'Ask who else has this exact problem before assuming it is unique to you',
      'Distinguish a real problem people already pay to solve badly from a preference they would just like solved',
    ],
    reflection: 'What is one thing you dealt with this week that felt harder than it needed to be?',
  ),
  const Lesson(
    id: 'm1_l2',
    title: 'Reading the Technology Wave',
    principle:
        'The best opportunities sit where a real problem meets a technology that just became cheap, fast, or accessible enough to solve it. Timing often matters more than the idea itself.',
    story:
        'Webvan tried online grocery delivery in 1999 and burned through hundreds of millions of dollars because broadband, smartphones, and GPS routing did not exist yet. Instacart launched the same idea in 2012, once smartphones and on-demand labor markets made it viable, and became a multi-billion dollar company.',
    bestPractices: [
      'Ask could this have existed 5 years ago, if yes, timing is not your advantage',
      'Track which underlying costs are dropping: compute, sensors, bandwidth, batteries, AI inference',
      'Do not confuse the idea is good with the idea is now possible cheaply',
    ],
    reflection: 'Name one technology that got dramatically cheaper or more capable in the last 2 years. What becomes possible now that was not before?',
  ),
  const Lesson(
    id: 'm1_l3',
    title: 'The Kodak Trap',
    principle:
        'Incumbents often see disruption coming and still fail to act because the new approach threatens their existing revenue. Recognizing this pattern helps you spot openings against slow-moving competitors.',
    story:
        'Kodak\'s own engineer invented the digital camera in 1975. Kodak shelved it because digital threatened their profitable film business. By the time they took digital seriously, Canon, Sony, and smartphones had already claimed the market. Kodak filed for bankruptcy in 2012.',
    bestPractices: [
      'Look for markets where the leader has a profitable reason to ignore a better technology',
      'Ask who benefits from things staying the way they are, that is your opening',
      'Do not wait for permission from an industry that has no incentive to change',
    ],
    reflection: 'Is there an industry you know well where the leaders are protecting an old model instead of adopting a better one?',
  ),
  const Lesson(
    id: 'm1_l4',
    title: 'Talk to Ten People Before You Build Anything',
    principle:
        'Founders fall in love with solutions before confirming the problem is real and painful enough that people will change behavior or pay to fix it.',
    story:
        'Airbnb\'s founders personally photographed early hosts\' listings and spoke with users constantly in the first year, not because they loved photography, but to learn firsthand what was stopping people from booking. That direct contact shaped nearly every early product decision.',
    bestPractices: [
      'Talk to potential customers before writing a line of code, aim for 10 real conversations',
      'Ask about their last time solving this problem rather than a hypothetical would you use this',
      'Listen for what they are already paying for or hacking together, that is signal',
    ],
    reflection: 'Who are 3 real people you could talk to this week about a problem you are curious about?',
  ),
  const Lesson(
    id: 'm1_l5',
    title: 'Niches Are Not Small Ideas',
    principle:
        'Nearly every large company started by serving a narrow, specific group extremely well before expanding. A small niche with real pain beats a big idea with no clear first customer.',
    story:
        'Facebook launched only for Harvard students. Amazon started with books only. Uber began as a black-car service for tech workers in San Francisco. Each dominated a narrow beachhead before expanding.',
    bestPractices: [
      'Pick a specific first customer you can describe in one sentence, not everyone',
      'Ask can I be the best in the world at serving this one group',
      'Expand only after you have genuinely won the first niche',
    ],
    reflection: 'If you had to pick one narrow group of people to serve first, who would it be and why?',
  ),
];
