import '../../models/module.dart';

final List<Lesson> module4Lessons = [
  const Lesson(
    id: 'm4_l1',
    title: 'Ship the Thinnest Slice That Works',
    principle:
        'A minimum viable product is the smallest thing that lets you learn something real from actual users, not a cheap version of your final vision.',
    story:
        'Buffer\'s founder launched with a two-page website: page one described the product, page two said coming soon, enter your email. Only after people tried to pay did he build the actual scheduling tool.',
    bestPractices: [
      'Cut your feature list to the one thing your idea cannot exist without',
      'Treat your first version as a question, not an answer',
      'Set a launch date that is uncomfortably soon and build backward from it',
    ],
    reflection: 'What is the one feature your idea absolutely cannot work without?',
  ),
  const Lesson(
    id: 'm4_l2',
    title: 'No-Code as a First Draft',
    principle:
        'You no longer need to know how to code to prove a business idea works. No-code and AI tools let founders test entire products in days.',
    story:
        'Several successful startups built their entire first version using no-code tools and used it to sign real paying customers before writing custom software. Investors funded the traction, not the tech stack.',
    bestPractices: [
      'Use no-code tools to fake the backend before building one',
      'Spend engineering time only on what is genuinely unique to your idea',
      'Plan to rebuild in custom code once you have outgrown the no-code version, not before',
    ],
    reflection: 'Which parts of your idea could be faked with existing tools instead of custom-built?',
  ),
  const Lesson(
    id: 'm4_l3',
    title: 'Building With AI as a Force Multiplier',
    principle:
        'AI coding assistants and generative tools let a single founder do what used to require a small team. The fastest-shifting skill is knowing what to ask for and how to judge the output.',
    story:
        'Picture a product manager with no engineering background who describes a feature in plain language, gets working code from an AI assistant, and tests it with real users the same day. Work that once meant weeks of waiting for a contractor now takes hours, but reviewing, testing, and securing the code stays the builder\'s job. This is an illustrative scenario.',
    bestPractices: [
      'Use AI tools to generate first drafts of code, copy, and designs, then apply your judgment',
      'Learn to write clear, specific instructions, vague prompts produce vague results',
      'Never ship AI-generated output you do not understand well enough to explain or fix',
    ],
    reflection: 'What is one part of building your idea you could hand to an AI tool as a first draft this week?',
  ),
  const Lesson(
    id: 'm4_l4',
    title: 'Technical Co-Founder or Not',
    principle:
        'Whether you need a technical co-founder depends on how much of your product is genuinely hard to build versus assembly of existing tools.',
    story:
        'Kevin Systrom began Instagram\'s ancestor, a location app called Burbn, largely on his own in his spare time. Once he saw people loved the photo features, Mike Krieger joined, and the two refocused the product on photos. When Facebook bought Instagram in April 2012 for 1 billion dollars, the company had just 13 employees.',
    bestPractices: [
      'Validate the idea manually or with no-code before recruiting a technical co-founder',
      'If you do need one, look for shared conviction about the problem, not just skill',
      'Consider a contractor or agency for a first build if a full co-founder is not the right fit yet',
    ],
    reflection: 'Honestly, is your idea blocked by a lack of technical skill, or by a lack of a validated problem?',
  ),
  const Lesson(
    id: 'm4_l5',
    title: 'Design for Trust Before Design for Beauty',
    principle:
        'Early customers forgive rough visuals but not signals of unreliability. Focus early design effort on clarity, speed, and trust cues.',
    story:
        'Craigslist has looked essentially the same since the 1990s and remains one of the most-used sites in the world, because its design serves function and trust rather than visual polish.',
    bestPractices: [
      'Make sure every core action works flawlessly before investing in visual design',
      'Show real information such as a real name, photo, or response time to build trust fast',
      'Get someone unfamiliar with your product to try it and watch where they hesitate',
    ],
    reflection: 'Where in your product might a new user hesitate because something feels untrustworthy or unclear?',
  ),
];
