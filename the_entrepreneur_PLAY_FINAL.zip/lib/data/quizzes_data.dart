import '../models/quiz.dart';

// Three questions per module, keyed by module id.
const Map<String, List<QuizQuestion>> moduleQuizzes = {
  'spotting_opportunity': [
    QuizQuestion(
      prompt: 'What is the best source of early product ideas according to this module?',
      options: ['Trend reports only', 'Everyday friction you or others experience', 'Copying the largest competitor', 'Random brainstorming'],
      answer: 1,
      explanation: 'Real, repeated frustration signals a problem people already want solved.',
    ),
    QuizQuestion(
      prompt: 'Why did Webvan struggle in 1999 while a similar idea worked later?',
      options: ['The idea was bad', 'Nobody wanted groceries', 'Supporting technology was not yet cheap or available', 'It had no investors'],
      answer: 2,
      explanation: 'Timing and enabling technology matter as much as the idea.',
    ),
    QuizQuestion(
      prompt: 'Which question gives the most reliable customer insight?',
      options: ['Would you use an app that does X?', 'Tell me about the last time you dealt with this', 'Do you like my idea?', 'How much would you pay in theory?'],
      answer: 1,
      explanation: 'Past behavior is more reliable than hypothetical promises.',
    ),
  ],
  'technology_wave': [
    QuizQuestion(
      prompt: 'When electricity first reached factories, why were early gains small?',
      options: ['Electricity was expensive', 'Factories only swapped the power source without redesigning work', 'Workers refused to use it', 'There was no demand'],
      answer: 1,
      explanation: 'Real gains came after factories were redesigned around the new technology.',
    ),
    QuizQuestion(
      prompt: 'Robots and automation pay off best for work that is...',
      options: ['Rare and creative', 'Repetitive, physical, and high volume', 'Done once a year', 'Purely emotional'],
      answer: 1,
      explanation: 'High-volume repetitive work gives automation the most chances to save money.',
    ),
    QuizQuestion(
      prompt: 'What does a platform change for small teams?',
      options: ['It removes all competition', 'It lowers the cost of starting and reaching customers', 'It guarantees success', 'It makes ideas unnecessary'],
      answer: 1,
      explanation: 'Platforms give small teams tools that once required large budgets.',
    ),
  ],
  'validating_idea': [
    QuizQuestion(
      prompt: 'What is a smoke test?',
      options: ['A security scan', 'A cheap experiment measuring real interest before building', 'A final product review', 'A legal filing'],
      answer: 1,
      explanation: 'A smoke test checks demand with minimal effort.',
    ),
    QuizQuestion(
      prompt: 'What does a concierge MVP involve?',
      options: ['Fully automated software', 'Delivering the service manually to early customers', 'Hiring a large team', 'Buying ads only'],
      answer: 1,
      explanation: 'Doing it by hand teaches you what to build.',
    ),
    QuizQuestion(
      prompt: 'What is the strongest proof of demand?',
      options: ['Compliments', 'Likes on social media', 'Someone paying or committing before it exists', 'A long waiting list of friends'],
      answer: 2,
      explanation: 'Money or real commitment beats polite interest.',
    ),
  ],
  'building_product': [
    QuizQuestion(
      prompt: 'What does shipping the thinnest slice mean?',
      options: ['Shipping with few bugs only', 'Building the smallest version that solves the core problem', 'Hiding unfinished work', 'Adding features slowly'],
      answer: 1,
      explanation: 'The thin slice tests the core value fast.',
    ),
    QuizQuestion(
      prompt: 'When using AI to build, who remains responsible for quality and safety?',
      options: ['The AI', 'The builder', 'The user', 'Nobody'],
      answer: 1,
      explanation: 'AI speeds work but judgment, testing, and safety stay with you.',
    ),
    QuizQuestion(
      prompt: 'Which builds trust first?',
      options: ['Beautiful animation', 'Clear, honest, reliable design', 'Many features', 'Bright colors'],
      answer: 1,
      explanation: 'Trust comes from clarity and reliability before beauty.',
    ),
  ],
  'business_investment': [
    QuizQuestion(
      prompt: 'What is a liquidation preference?',
      options: ['A fee for cashing out', 'A term saying some investors are paid first when a company is sold', 'A tax', 'A type of loan'],
      answer: 1,
      explanation: 'It decides who gets paid first in a sale, so it can affect founders sharply.',
    ),
    QuizQuestion(
      prompt: 'Contribution per customer equals...',
      options: ['Price minus cost to serve', 'Price plus cost', 'Price divided by two', 'Cost minus price'],
      answer: 0,
      explanation: 'It is the amount each customer adds after direct costs.',
    ),
    QuizQuestion(
      prompt: 'Which is true about outside funding?',
      options: ['It is required for all companies', 'It is a choice with trade-offs', 'It guarantees growth', 'It removes risk'],
      answer: 1,
      explanation: 'Mailchimp and Basecamp show large companies can grow without it.',
    ),
  ],
  'go_to_market': [
    QuizQuestion(
      prompt: 'What is positioning?',
      options: ['Your office location', 'The clear idea customers associate with your product', 'Your price list', 'Your logo'],
      answer: 1,
      explanation: 'Positioning is the one idea you own in the customer\'s mind.',
    ),
    QuizQuestion(
      prompt: 'Where do your first 100 customers usually come from?',
      options: ['Big ad campaigns', 'Direct, personal effort', 'Luck', 'Press releases only'],
      answer: 1,
      explanation: 'Early customers come from personal outreach and manual work.',
    ),
    QuizQuestion(
      prompt: 'Why does retention matter so much?',
      options: ['It is cheaper than finding new customers and shows real value', 'It is required by law', 'It lowers prices', 'It replaces marketing'],
      answer: 0,
      explanation: 'Customers who stay prove the product delivers value.',
    ),
  ],
  'scaling_operations': [
    QuizQuestion(
      prompt: 'When should you automate a process?',
      options: ['Immediately', 'After it works well by hand', 'Never', 'Only when investors ask'],
      answer: 1,
      explanation: 'Automate a good process, not a broken one.',
    ),
    QuizQuestion(
      prompt: 'What is culture, according to this module?',
      options: ['The poster on the wall', 'The behavior you repeat and reward', 'The office layout', 'The mission statement only'],
      answer: 1,
      explanation: 'Culture is shown by decisions and repeated behavior.',
    ),
    QuizQuestion(
      prompt: 'Why might a company say no to growth?',
      options: ['To avoid customers', 'To protect what makes it good', 'Because growth is bad', 'To save paper'],
      answer: 1,
      explanation: 'Declining poorly fitting growth protects focus and quality.',
    ),
  ],
  'ai_native_products': [
    QuizQuestion(
      prompt: 'What makes an AI product defensible?',
      options: ['Using the newest model', 'A workflow, data, or trust competitors cannot copy', 'A bigger logo', 'More buttons'],
      answer: 1,
      explanation: 'The model is a commodity. Workflow, data, and trust create the moat.',
    ),
    QuizQuestion(
      prompt: 'Why should you build a test set for an AI feature?',
      options: ['To impress investors', 'To check quality on real examples after every change', 'To lower costs', 'To avoid users'],
      answer: 1,
      explanation: 'Testing on real cases catches mistakes before customers do.',
    ),
    QuizQuestion(
      prompt: 'What can quietly turn a flat-fee AI product into a loss?',
      options: ['Heavy users with high usage costs', 'Too many colors', 'Slow launches', 'Good reviews'],
      answer: 0,
      explanation: 'AI usage has a real cost per request, so heavy users can erase the margin.',
    ),
  ],
  'global_emerging_markets': [
    QuizQuestion(
      prompt: 'What does leapfrogging mean?',
      options: ['Copying a rival', 'Skipping an older stage and adopting newer technology directly', 'Moving offices', 'Slow growth'],
      answer: 1,
      explanation: 'M-Pesa let people skip traditional branch banking.',
    ),
    QuizQuestion(
      prompt: 'What does M-Pesa stand for?',
      options: ['Mobile plus Swahili word for money', 'Money plus Peace', 'Market Payment System', 'Mobile Payment Service'],
      answer: 0,
      explanation: 'M stands for mobile, and pesa is Swahili for money.',
    ),
    QuizQuestion(
      prompt: 'In a new market, what often beats size and brand?',
      options: ['Local trust and habits', 'Lower quality', 'Bigger offices', 'More ads'],
      answer: 0,
      explanation: 'Taobao beat a bigger foreign brand by understanding local trust.',
    ),
  ],
  'resilience_ethics': [
    QuizQuestion(
      prompt: 'How should a founder treat rejection?',
      options: ['Ignore it', 'As information to learn from', 'As proof of failure', 'As a reason to quit'],
      answer: 1,
      explanation: 'Patterns in rejection reveal what to change and what to keep.',
    ),
    QuizQuestion(
      prompt: 'How did Fujifilm survive the decline of film?',
      options: ['By cutting all research', 'By applying its chemistry and optics skills to new markets', 'By copying Kodak', 'By raising prices'],
      answer: 1,
      explanation: 'It redefined itself by capability, not by its current product.',
    ),
    QuizQuestion(
      prompt: 'Why state clear promises about how you treat users?',
      options: ['They are required for sales', 'They build lasting trust and hold you accountable', 'They slow growth', 'They reduce users'],
      answer: 1,
      explanation: 'Clear promises create trust and make shortcuts harder.',
    ),
  ],
};
