import '../models/case_study.dart';

final List<DeepFounder> deepFounders = [
  const DeepFounder(
    id: 'sara_blakely',
    name: 'Sara Blakely',
    company: 'Spanx',
    chapters: [
      FounderChapter(
        number: 1,
        title: 'The \$5,000 Idea With No Experience',
        content:
            'Sara Blakely had no fashion background, no funding, and no connections when she cut the feet off a pair of pantyhose to solve her own problem: visible panty lines under white pants. She worked on the idea while holding a full-time sales job, and she started with \$5,000 in savings and no outside investment, keeping 100 percent ownership. In 2012 she was named the youngest self-made female billionaire by Forbes, having never raised venture capital.',
      ),
      FounderChapter(
        number: 2,
        title: 'Patents, Rejection, and the One Yes',
        content:
            'Blakely drafted much of her own patent application, then paid a patent attorney about \$750 to finish it. She called hosiery mills across the industry and most turned her down. A mill operator in Asheboro, North Carolina, called her back about two weeks later and agreed to help, after, by her account, his daughters encouraged him to take the idea seriously. Her \$5,000 in savings covered patents, prototypes, and early costs over roughly two years.',
      ),
      FounderChapter(
        number: 3,
        title: 'The Neiman Marcus Break',
        content:
            'Blakely pitched a Neiman Marcus buyer in person and, when words were not enough, demonstrated the product in a store restroom so the buyer could see the difference right away. That high-conviction, in-person demo won her first major retail placement, with no advertising budget and no sales team.',
      ),
      FounderChapter(
        number: 4,
        title: 'Oprah, and the Power of One Endorsement',
        content:
            'Blakely sent a gift basket with Spanx to Oprah Winfrey\'s show, and in November 2000 Oprah named Spanx one of her Favorite Things. Sales surged without traditional advertising. The break came from a bold, personal act of outreach that she followed through on.',
      ),
      FounderChapter(
        number: 5,
        title: 'Staying Founder-Owned',
        content:
            'Blakely kept full ownership for more than two decades and funded growth from company revenue. In October 2021 the private equity firm Blackstone took a majority stake at a reported valuation of 1.2 billion dollars, about 21 years after Spanx began, while she remained involved with the company. Her path shows that outside capital is a choice, not a requirement.',
      ),
    ],
  ),
  const DeepFounder(
    id: 'jan_koum',
    name: 'Jan Koum',
    company: 'WhatsApp',
    chapters: [
      FounderChapter(
        number: 1,
        title: 'Rejected by Facebook, Then Sold to Facebook',
        content:
            'Jan Koum grew up in Ukraine in the Soviet era and moved to the United States as a teenager, where his family relied on public assistance. He worked at Yahoo, where he met Brian Acton. Both applied for jobs at Facebook in 2009 and were turned down. That same year Koum started WhatsApp, and Acton soon joined as a co-founder. Five years later, Facebook agreed to buy it for about 19 billion dollars.',
      ),
      FounderChapter(
        number: 2,
        title: 'The No-Ads Philosophy',
        content:
            'Koum kept a note taped to his desk reading "No Ads! No Games! No Gimmicks!" It summed up WhatsApp\'s founding promise: a fast, reliable messaging service that respected users\' time and data, instead of the advertising-driven model most free apps relied on.',
      ),
      FounderChapter(
        number: 3,
        title: 'A Tiny Team, a Huge Audience',
        content:
            'When the Facebook deal was announced in February 2014, WhatsApp had roughly 450 million users and only about 55 employees, with around 32 engineers. That extreme ratio came from focusing on one core function, messaging, instead of expanding into unrelated features.',
      ),
      FounderChapter(
        number: 4,
        title: 'Where the Deal Was Signed',
        content:
            'Koum signed the Facebook agreement at the former welfare office in Mountain View, California, where he had once stood in line for food stamps. It was a deliberate reminder of how far the company, and he, had come.',
      ),
      FounderChapter(
        number: 5,
        title: 'The Ideological Split',
        content:
            'Acton left Facebook in 2017, and Koum announced he was leaving in 2018, reportedly after disagreements over data privacy and plans to use WhatsApp for advertising. Even after a huge financial outcome, they showed that some founders walk away over values.',
      ),
    ],
  ),
  const DeepFounder(
    id: 'melanie_perkins',
    name: 'Melanie Perkins',
    company: 'Canva',
    chapters: [
      FounderChapter(
        number: 1,
        title: 'Yearbooks First',
        content:
            'Melanie Perkins was born in Perth, Western Australia, in 1987 and studied communications, psychology, and commerce at the University of Western Australia. In 2007 she and Cliff Obrecht co-founded Fusion Books, a web-based yearbook service where schools could design pages with drag-and-drop tools. It grew in Australia and later reached New Zealand and France.',
      ),
      FounderChapter(
        number: 2,
        title: 'A Bigger Idea',
        content:
            'Running Fusion Books showed her that design software was too hard for most people. That insight pointed to a much larger idea: a simple online design platform anyone could use. To build it she needed funding, and in 2013 she went to San Francisco to find investors.',
      ),
      FounderChapter(
        number: 3,
        title: 'Over 100 Rejections',
        content:
            'In 2013 Perkins and Obrecht spent months seeking venture capital and were rejected by more than 100 investors. She kept refining the pitch and the product. Canva launched publicly in 2013. A few investors believed in the vision, and the company grew from there.',
      ),
      FounderChapter(
        number: 4,
        title: 'One Leader, One Mission',
        content:
            'After advice from an investor that the company should have a single leader, Obrecht nominated Perkins as CEO. In 2021 the couple joined the Giving Pledge, committing to give away most of their wealth through the Canva Foundation. Her story shows how a patient founder can turn a long run of no into a global product.',
      ),
    ],
  ),
  const DeepFounder(
    id: 'reed_hastings',
    name: 'Reed Hastings and Marc Randolph',
    company: 'Netflix',
    chapters: [
      FounderChapter(
        number: 1,
        title: 'Two Colleagues, No Clear Idea',
        content:
            'Reed Hastings and Marc Randolph worked together at Pure Atria and were facing redundancy. During their commute they brainstormed business ideas. Netflix did not start from a single flash of inspiration. It came from a process of elimination, and mailing videotapes was too expensive until DVD technology made renting by mail practical.',
      ),
      FounderChapter(
        number: 2,
        title: 'The Late Fee Myth',
        content:
            'A popular story says Hastings started Netflix after a 40 dollar late fee on the film Apollo 13. Hastings has said the fine did happen, but it was not the single spark that created the company. The true story is a team testing a practical idea, not a one-moment legend.',
      ),
      FounderChapter(
        number: 3,
        title: 'The 50 Million Dollar Offer',
        content:
            'In 2000, when Netflix was struggling, Hastings and Randolph met Blockbuster CEO John Antioco and offered to sell Netflix for 50 million dollars, with Netflix becoming Blockbuster\'s online arm. Blockbuster declined, and Netflix people later said they were nearly laughed out of the room.',
      ),
      FounderChapter(
        number: 4,
        title: 'Why Blockbuster Fell',
        content:
            'Blockbuster collected about 800 million dollars in late fees in 2000 and carried heavy debt. Netflix offered flat-rate DVD rental by mail with no late fees, passed one million subscribers within about three years of the Blockbuster rejection, and reached six million by the end of 2006. Blockbuster filed for bankruptcy in 2010. The lesson: a rival who depends on your pain point is hard to compete with, and easy to outflank.',
      ),
    ],
  ),
  const DeepFounder(
    id: 'jack_ma',
    name: 'Jack Ma',
    company: 'Alibaba',
    chapters: [
      FounderChapter(
        number: 1,
        title: 'Many Nos Before the First Yes',
        content:
            'Jack Ma failed China\'s college entrance exam twice before passing. As a teenager he practiced English by guiding tourists around Hangzhou. After graduating in 1988 he taught English and international trade. He has said he applied for about 30 jobs and was rejected by all of them, including a KFC position.',
      ),
      FounderChapter(
        number: 2,
        title: 'Friends and an Apartment',
        content:
            'In 1999 Ma founded Alibaba in his apartment with a group of friends. In October 1999 and January 2000 the company raised a total of 25 million dollars from Goldman Sachs and SoftBank. It became profitable about three years later.',
      ),
      FounderChapter(
        number: 3,
        title: 'Taobao Versus eBay',
        content:
            'After Taobao grew quickly against eBay in China, eBay offered to buy it. Ma refused and instead secured a one billion dollar investment led by Yahoo co-founder Jerry Yang. Taobao and Alipay were designed around local buyer and seller trust.',
      ),
      FounderChapter(
        number: 4,
        title: 'The Biggest IPO and a Quiet Exit',
        content:
            'In 2014 Alibaba raised about 25 billion dollars in its New York Stock Exchange IPO, then the largest in United States history. Ma announced in 2018 he would step down as executive chairman and left the board in September 2019.',
      ),
    ],
  ),
  const DeepFounder(
    id: 'strive_masiyiwa',
    name: 'Strive Masiyiwa',
    company: 'Econet',
    chapters: [
      FounderChapter(
        number: 1,
        title: 'From Engineer to Founder',
        content:
            'Strive Masiyiwa was born in 1961 in what was then Rhodesia. He studied electrical and electronics engineering on a scholarship in Wales, returned to Zimbabwe in 1984, and worked at the state telecom body PTC. In 1988 he left to found an engineering firm.',
      ),
      FounderChapter(
        number: 2,
        title: 'A Monopoly Says No',
        content:
            'In 1993 Masiyiwa proposed a mobile network to PTC, the state monopoly. PTC rejected his plan, and when he pursued it alone, the government blocked his licence. He later asked what sort of law lets an agency stop someone from doing something the agency does not do itself.',
      ),
      FounderChapter(
        number: 3,
        title: 'Five Years in Court',
        content:
            'Masiyiwa went to court. The High Court first ruled for him, the Supreme Court overturned that in 1994, then he won again in 1995, and a final order in 1997 required the government to issue a licence. Throughout, he says he faced political pressure and alleged bribe demands.',
      ),
      FounderChapter(
        number: 4,
        title: 'Launch and Legacy',
        content:
            'Econet Wireless Zimbabwe launched in June 1998. The group grew across Africa and beyond, and Masiyiwa became a driving force behind Liquid Telecom, a fibre-optic and satellite provider, and a funder of foundations for disadvantaged people. His story shows persistence against unfair rules, and the value of knowing your rights.',
      ),
    ],
  ),
];

final List<ShortCase> shortCases = [
  const ShortCase(
    id: 'spanx',
    company: 'Spanx',
    story: 'Sara Blakely cut the feet off pantyhose to solve her own annoying problem, with no fashion background and \$5,000 in savings.',
    lesson: 'Solve your own annoying problem first.',
  ),
  const ShortCase(
    id: 'whatsapp',
    company: 'WhatsApp',
    story: 'Jan Koum and Brian Acton focused on speed and reliability, refusing ads and feature creep. At the 2014 deal the company had about 55 employees.',
    lesson: 'Obsess over one core promise, ignore feature creep.',
  ),
  const ShortCase(
    id: 'airbnb_unscalable',
    company: 'Airbnb',
    story: 'Founders personally photographed early hosts\' apartments instead of waiting for a scalable solution.',
    lesson: 'Hands-on effort beats premature automation.',
  ),
  const ShortCase(
    id: 'canva',
    company: 'Canva',
    story: 'Melanie Perkins and Cliff Obrecht were rejected by more than 100 investors in 2013 while pitching a simple design tool.',
    lesson: 'Rejection volume is not proof an idea is wrong. Sometimes it just needs the right believer.',
  ),
  const ShortCase(
    id: 'slack_pivot',
    company: 'Slack',
    story: 'A failed video game called Glitch never gained traction, but the internal messaging tool built for its team became Slack.',
    lesson: 'Watch for the real value hiding inside a failing project.',
  ),
  const ShortCase(
    id: 'dropbox_video',
    company: 'Dropbox',
    story: 'A simple screen-recording demo video is widely reported to have driven the beta waitlist from 5,000 to 75,000 overnight, before the full product existed.',
    lesson: 'A demo can prove demand before you build anything.',
  ),
  const ShortCase(
    id: 'kodak',
    company: 'Kodak',
    story: 'Kodak\'s own engineer built the first digital camera in 1975. The company protected its film revenue and filed for bankruptcy in January 2012.',
    lesson: 'Protecting an old model can be more dangerous than disrupting it yourself.',
  ),
  const ShortCase(
    id: 'pebble',
    company: 'Pebble',
    story: 'The Pebble smartwatch raised over 10 million dollars in pre-orders on Kickstarter in 2012, funding manufacturing directly from customers.',
    lesson: 'You can fund and validate a product in the same move, without giving up equity.',
  ),
  const ShortCase(
    id: 'superhuman',
    company: 'Superhuman',
    story: 'Superhuman priced its email app at 30 dollars a month against free competitors, using price to signal quality.',
    lesson: 'Price can filter for the right customers, not just cover costs.',
  ),
  const ShortCase(
    id: 'basecamp',
    company: 'Basecamp',
    story: 'Basecamp built a profitable, founder-controlled company for two decades without outside venture capital.',
    lesson: 'Outside capital is a choice, not a requirement.',
  ),
  const ShortCase(
    id: 'airbnb_cereal',
    company: 'Airbnb Cereal Boxes',
    story: 'During the 2008 election season Airbnb\'s founders designed and sold novelty cereal boxes and raised about 30,000 dollars to keep going, a story the founders have told in many interviews.',
    lesson: 'Creative, scrappy funding can keep you alive until the market catches up.',
  ),
  const ShortCase(
    id: 'instagram',
    company: 'Instagram',
    story: 'Kevin Systrom began with a location app called Burbn, joined by Mike Krieger, and refocused on photos. Facebook bought Instagram in April 2012 for 1 billion dollars when it had 13 employees.',
    lesson: 'Find the one feature people love and drop the rest.',
  ),
  const ShortCase(
    id: 'mpesa',
    company: 'M-Pesa',
    story: 'Launched by Safaricom and Vodafone, with a pilot in 2005 and full launch in 2007 in Kenya, to help borrowers repay microloans. It grew into a mobile payment system used by millions.',
    lesson: 'The most successful use can differ from your original plan. Watch what users do.',
  ),
  const ShortCase(
    id: 'dyson',
    company: 'Dyson',
    story: 'James Dyson made about 5,127 prototypes over five years before his cyclonic vacuum worked. The G-Force launched in Japan in 1983 after manufacturers turned him down.',
    lesson: 'Persistent iteration, plus selling where the market is willing to listen.',
  ),
  const ShortCase(
    id: 'dollar_shave_club',
    company: 'Dollar Shave Club',
    story: 'Founded by Mark Levine and Michael Dubin, it launched its subscription with a YouTube video in March 2012 and reportedly got about 12,000 orders in 48 hours. Unilever bought it in 2016 for a reported 1 billion dollars.',
    lesson: 'A clear message and a simple subscription can break open an old market.',
  ),
  const ShortCase(
    id: 'mailchimp',
    company: 'Mailchimp',
    story: 'Founded in 2001 by Ben Chestnut and Mark Armstrong, Mailchimp never took outside investors. Intuit agreed to acquire it in 2021 for about 12 billion dollars.',
    lesson: 'Bootstrapping can build something enormous and keep the founders in control.',
  ),
  const ShortCase(
    id: 'lego',
    company: 'Lego',
    story: 'Around 2004 Lego was on the brink of bankruptcy after its parts count and product lines ballooned. New CEO Jorgen Vig Knudstorp cut costs, trimmed parts from 12,000 to about 6,000, and refocused on core sets.',
    lesson: 'Complexity can quietly kill a healthy brand. Simplify to survive.',
  ),
  const ShortCase(
    id: 'grameen',
    company: 'Grameen Bank',
    story: 'In 1976 Muhammad Yunus lent small sums of his own money to villagers in Jobra, Bangladesh. The idea grew into Grameen Bank, and he and the bank won the Nobel Peace Prize in 2006.',
    lesson: 'Small, trust-based loans can serve people ordinary banks ignore.',
  ),
  const ShortCase(
    id: 'twitter_odeo',
    company: 'Twitter and Odeo',
    story: 'Evan Williams\' podcasting company Odeo was struggling when a side prototype for short messages, built with Jack Dorsey and Biz Stone, became Twitter in 2006.',
    lesson: 'A side project can become the main business.',
  ),
  const ShortCase(
    id: 'fujifilm',
    company: 'Fujifilm',
    story: 'While Kodak went bankrupt, Fujifilm asked what its strengths in chemistry and optics could serve, and expanded into healthcare, cosmetics, and more under a 2004 restructuring plan.',
    lesson: 'Redefine your company by its capability, not its current product.',
  ),
];
