import '../models/toolkit_item.dart';

final List<ToolkitItem> toolkitItems = [
  const ToolkitItem(
    id: 'problem_statement',
    title: 'One-Sentence Problem Statement',
    category: 'Opportunity',
    content:
        '[Specific group of people] struggle with [specific problem] because [root cause], which costs them [time, money, or frustration].',
  ),
  const ToolkitItem(
    id: 'positioning_statement',
    title: 'One-Sentence Positioning Statement',
    category: 'Go-to-Market',
    content:
        'For [target customer], who [need or problem], [product] is the [category] that [key differentiator], unlike [main alternative].',
  ),
  const ToolkitItem(
    id: 'smoke_test_checklist',
    title: 'Smoke Test Checklist',
    category: 'Validation',
    content:
        'Landing page describing the outcome, not the features. One clear call-to-action. A way to measure real commitment. A target number to hit before building anything further.',
  ),
  const ToolkitItem(
    id: 'interview_script',
    title: 'Customer Interview Script',
    category: 'Validation',
    content:
        'Walk me through the last time you dealt with [problem]. What have you already tried to fix it? What do not you love about what you are using now? Who else deals with this the way you do? Never ask would you use.',
  ),
  const ToolkitItem(
    id: 'unit_economics',
    title: 'Unit Economics Quick Calculator',
    category: 'Business Model',
    content:
        'Customer Acquisition Cost equals total sales and marketing spend divided by new customers acquired. Customer Lifetime Value equals average revenue per customer times average customer lifespan. Healthy target: LTV at least 3x CAC.',
  ),
  const ToolkitItem(
    id: 'pitch_deck_outline',
    title: 'Basic Pitch Deck Outline',
    category: 'Investment',
    content:
        '1. Problem 2. Solution 3. Why now 4. Market size 5. Product demo 6. Business model 7. Traction 8. Competition 9. Team 10. The ask.',
  ),
  const ToolkitItem(
    id: 'investor_email',
    title: 'Investor Outreach Email Script',
    category: 'Investment',
    content:
        'Subject: [Your company], one-line description. Body: one sentence on the problem, one sentence on traction or evidence, one sentence on the ask, a short bio line, and a link to a deck or demo. Keep it under 100 words.',
  ),
  const ToolkitItem(
    id: 'hiring_checklist',
    title: 'Hiring Stage Checklist',
    category: 'Operations',
    content:
        'Can you describe this role\'s success in one measurable sentence? Does this hire need to be a generalist or a specialist? Have you validated the need with at least 2 months of clear, recurring pain?',
  ),
  const ToolkitItem(
    id: 'culture_filter',
    title: 'Culture Decision Filter',
    category: 'Operations',
    content:
        'Before any major decision ask: does this reinforce or contradict what we say we value? If it contradicts, either change the decision or change what you claim to value.',
  ),
  const ToolkitItem(
    id: 'growth_no_list',
    title: 'Growth No List Template',
    category: 'Operations',
    content:
        'We will say no to [type of customer or opportunity] even if it offers [tempting benefit], because it would cost us [core focus or value].',
  ),
  const ToolkitItem(
    id: 'pre_mortem',
    title: 'Pre-Mortem Checklist',
    category: 'Validation',
    content:
        'Imagine it is one year from now and the idea has failed. Write the three most likely reasons. For each, write one action you can take this month to reduce the risk.',
  ),
  const ToolkitItem(
    id: 'ai_feature_test_set',
    title: 'AI Feature Test Set',
    category: 'AI Products',
    content:
        'Collect 10 to 20 real examples your AI feature must handle. Write the correct answer for each. Run them after every change. Track how many pass, and add any new failure you discover.',
  ),
  const ToolkitItem(
    id: 'pitch_outline',
    title: 'Four-Sentence Pitch',
    category: 'Investment',
    content:
        'Sentence 1: the problem and who has it. Sentence 2: your solution. Sentence 3: proof so far, such as users, revenue, or pre-orders. Sentence 4: what you are asking for and what you will do with it.',
  ),
  const ToolkitItem(
    id: 'trust_promises',
    title: 'Three Trust Promises',
    category: 'Ethics',
    content:
        'Write three promises you will keep to your customers, such as what data you collect, how you charge, and how they can leave. Share them publicly so you can be held to them.',
  ),
];
