import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/module.dart';
import '../services/progress_db.dart';
import '../data/lesson_extras.dart';

class LessonScreen extends StatefulWidget {
  final Module module;
  final Lesson lesson;
  const LessonScreen({super.key, required this.module, required this.lesson});

  @override
  State<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends State<LessonScreen> {
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final completed = await ProgressDb.instance.getCompletedLessonIds();
    if (mounted) setState(() => _done = completed.contains(widget.lesson.id));
  }

  Future<void> _toggleDone() async {
    if (_done) {
      await ProgressDb.instance.unmarkLessonComplete(widget.lesson.id);
    } else {
      await ProgressDb.instance.markLessonComplete(widget.lesson.id);
    }
    _load();
  }

  Lesson? get _nextLesson {
    final lessons = widget.module.lessons;
    final i = lessons.indexWhere((l) => l.id == widget.lesson.id);
    if (i >= 0 && i + 1 < lessons.length) return lessons[i + 1];
    return null;
  }

  Widget _label(String text) => Text(
        text,
        style: const TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: AppColors.teal, letterSpacing: 1),
      );

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;
    final next = _nextLesson;
    final extra = lessonExtras[lesson.id];

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: AppColors.navy,
            pinned: true,
            expandedHeight: 130,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.fromLTRB(56, 0, 20, 16),
              title: Text(lesson.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
              background: Container(color: AppColors.navy),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _label('PRINCIPLE'),
                const SizedBox(height: 6),
                Text(lesson.principle, style: const TextStyle(fontSize: 14, height: 1.65, color: AppColors.ink)),
                const SizedBox(height: 20),
                _label('STORY'),
                const SizedBox(height: 6),
                Container(
                  decoration: const BoxDecoration(
                    color: AppColors.tealLight,
                    borderRadius: BorderRadius.horizontal(right: Radius.circular(12)),
                    border: Border(left: BorderSide(color: AppColors.teal, width: 3)),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Text(lesson.story, style: const TextStyle(fontSize: 13, height: 1.6, color: AppColors.ink)),
                ),
                const SizedBox(height: 20),
                _label('BEST PRACTICES'),
                const SizedBox(height: 8),
                ...lesson.bestPractices.map((p) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(top: 3),
                            width: 16,
                            height: 16,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              border: Border.all(color: AppColors.teal, width: 1.5),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(child: Text(p, style: const TextStyle(fontSize: 13, height: 1.55, color: AppColors.ink))),
                        ],
                      ),
                    )),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.navyLight, borderRadius: BorderRadius.circular(14)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('REFLECT',
                          style: TextStyle(fontFamily: 'monospace', fontSize: 10, color: AppColors.gold, letterSpacing: 1)),
                      const SizedBox(height: 8),
                      Text(lesson.reflection,
                          style: const TextStyle(
                              fontSize: 13, fontStyle: FontStyle.italic, color: Color(0xFFDCE1EC), height: 1.6)),
                    ],
                  ),
                ),
                if (extra != null) ...[
                  const SizedBox(height: 20),
                  _label('KEY TAKEAWAY'),
                  const SizedBox(height: 6),
                  Text(extra.takeaway,
                      style: const TextStyle(fontSize: 14, height: 1.55, fontWeight: FontWeight.w600, color: AppColors.navy)),
                  const SizedBox(height: 20),
                  _label('TRY THIS TODAY'),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.gold, width: 1.2),
                    ),
                    child: Text(extra.tryThis, style: const TextStyle(fontSize: 13, height: 1.55, color: AppColors.ink)),
                  ),
                ],
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _toggleDone,
                    icon: Icon(_done ? Icons.check_circle : Icons.check_circle_outline),
                    label: Text(_done ? 'Marked as read' : 'Mark as read'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _done ? AppColors.teal : AppColors.gold,
                      foregroundColor: _done ? Colors.white : AppColors.navy,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                if (next != null) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => LessonScreen(module: widget.module, lesson: next)),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.navy,
                        side: const BorderSide(color: AppColors.navy),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: Text('Next lesson: ${next.title}', maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                ],
                const SizedBox(height: 12),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
