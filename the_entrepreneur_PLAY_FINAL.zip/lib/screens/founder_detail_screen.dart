import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/case_study.dart';

class FounderDetailScreen extends StatelessWidget {
  final DeepFounder founder;
  const FounderDetailScreen({super.key, required this.founder});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(founder.name)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(founder.company, style: const TextStyle(fontSize: 13, color: AppColors.gold, fontFamily: 'monospace')),
          const SizedBox(height: 14),
          ...founder.chapters.map((ch) => Container(
                margin: const EdgeInsets.only(bottom: 14),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.cardBorder)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('CHAPTER ${ch.number}', style: const TextStyle(fontFamily: 'monospace', fontSize: 10, color: AppColors.teal, letterSpacing: 1)),
                    const SizedBox(height: 6),
                    Text(ch.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.navy)),
                    const SizedBox(height: 8),
                    Text(ch.content, style: const TextStyle(fontSize: 13, height: 1.6, color: AppColors.ink)),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}
