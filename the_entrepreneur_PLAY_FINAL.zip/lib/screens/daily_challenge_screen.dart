import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../data/daily_challenges.dart';
import '../services/progress_db.dart';

class DailyChallengeScreen extends StatefulWidget {
  const DailyChallengeScreen({super.key});

  @override
  State<DailyChallengeScreen> createState() => _DailyChallengeScreenState();
}

class _DailyChallengeScreenState extends State<DailyChallengeScreen> {
  bool _done = false;
  int _streak = 0;
  int _total = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = ProgressDb.instance;
    final done = await db.isTodayComplete();
    final streak = await db.getCurrentStreak();
    final total = await db.getCompletedChallengeCount();
    if (mounted) {
      setState(() {
        _done = done;
        _streak = streak;
        _total = total;
      });
    }
  }

  Future<void> _complete() async {
    await ProgressDb.instance.markTodayComplete(todayChallengeIndex());
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final index = todayChallengeIndex();
    final challenge = dailyChallenges[index];
    return Scaffold(
      appBar: AppBar(title: const Text('Daily Challenge')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            children: [
              Expanded(child: _stat('Current streak', '$_streak days')),
              const SizedBox(width: 10),
              Expanded(child: _stat('Completed', '$_total')),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(18)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TODAY, CHALLENGE ${index + 1} OF ${dailyChallenges.length}',
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 10, color: AppColors.gold, letterSpacing: 1)),
                const SizedBox(height: 10),
                Text(challenge,
                    style: const TextStyle(color: Colors.white, fontSize: 16, height: 1.5, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _done ? null : _complete,
              icon: Icon(_done ? Icons.check_circle : Icons.check_circle_outline),
              label: Text(_done ? 'Completed today' : 'Mark complete'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _done ? AppColors.teal : AppColors.gold,
                foregroundColor: _done ? Colors.white : AppColors.navy,
                disabledBackgroundColor: AppColors.teal,
                disabledForegroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text('ALL ${dailyChallenges.length} CHALLENGES',
              style: TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: AppColors.teal, letterSpacing: 1)),
          const SizedBox(height: 10),
          ...List.generate(dailyChallenges.length, (i) {
            final isToday = i == index;
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: isToday ? AppColors.gold : AppColors.cardBorder, width: isToday ? 1.5 : 1),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 28,
                    child: Text('${i + 1}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: AppColors.teal)),
                  ),
                  Expanded(
                    child: Text(dailyChallenges[i],
                        style: const TextStyle(fontSize: 12.5, height: 1.45, color: AppColors.ink)),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.navy)),
        ],
      ),
    );
  }
}
