import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

// ============================================================================
// WEEGIX "ABOUT" SCREEN - SHARED CROSS-APP TEMPLATE
// ============================================================================
// This screen's layout, palette, and structure are intentionally identical
// across every Weegix app (Eliana, SPROUT, FamSync, Lumi, Mshindi, StatGuru,
// LeadForge, SciForge, RaiseWell, and now The Entrepreneur). It deliberately
// does NOT use the host app's own AppTheme colors, it always uses this fixed
// navy/teal/gold Weegix palette, so the "About" experience feels the same
// no matter which app it's opened from.
// ============================================================================

class _WeegixColors {
  static const navy = Color(0xFF0F172A);
  static const navyLight = Color(0xFF1E3A5F);
  static const teal = Color(0xFF14B8A6);
  static const gold = Color(0xFFD97706);
  static const bg = Color(0xFFF8FAFC);
  static const textDark = Color(0xFF1E293B);
  static const textMuted = Color(0xFF64748B);
}

class PortfolioApp {
  final String name;
  final String emoji;
  final String description;
  final bool isCurrentApp;
  final String? storeUrl; // null = not yet published / no direct link
  const PortfolioApp({
    required this.name,
    required this.emoji,
    required this.description,
    this.isCurrentApp = false,
    this.storeUrl,
  });
}

// ---- Edit this list per-app: only the isCurrentApp flag should change. ----
const List<PortfolioApp> _portfolio = [
  PortfolioApp(
    name: 'The Entrepreneur',
    emoji: '🚀',
    description: 'Learn to spot opportunity, ride the AI, internet, robotics, and industrial waves, and build real market solutions.',
    isCurrentApp: true,
  ),
  PortfolioApp(
    name: 'LeadForge',
    emoji: '🔥',
    description: 'Leadership development: styles, communication, decision-making, and a full leadership library.',
  ),
  PortfolioApp(
    name: 'SciForge',
    emoji: '🔬',
    description: '20 science and math fields made real-world and practical, from Chemistry to Psychology.',
  ),
  PortfolioApp(
    name: 'RaiseWell',
    emoji: '🌳',
    description: 'Parenting guidance from the womb to the launch years, real frameworks made easy to read.',
  ),
  PortfolioApp(
    name: 'SPROUT',
    emoji: '🌱',
    description: 'Church community & spiritual growth app: events, giving, and connection for the Eritrean Orthodox Tewahedo community.',
    storeUrl: 'https://play.google.com/store/apps/details?id=com.tewahedo.sprout',
  ),
  PortfolioApp(
    name: 'Eliana',
    emoji: '🔤',
    description: 'Tigrigna (Ge\'ez fidel) learning app for children: alphabet, tracing, and language foundations.',
  ),
  PortfolioApp(
    name: 'Lumi',
    emoji: '✨',
    description: 'English early-learning app for kids: letters, reading, math, and stories, with content that grows with your child.',
  ),
  PortfolioApp(
    name: 'FamSync',
    emoji: '👨‍👩‍👧‍👦',
    description: 'Family organizer: shared tasks, shopping lists, schedules, and challenges to keep the whole household in sync.',
  ),
  PortfolioApp(
    name: 'Mshindi',
    emoji: '💪',
    description: 'Fitness and wellness companion: workouts, tracking, and healthy habits.',
  ),
  PortfolioApp(
    name: 'StatGuru',
    emoji: '📊',
    description: 'Statistics learning app: real-world scenarios, challenges, and guided projects.',
  ),
  PortfolioApp(
    name: 'LoopPM',
    emoji: '🔄',
    description: 'Agentic project management: zero-data-entry planning that adapts as work happens.',
  ),
  PortfolioApp(
    name: 'More coming soon',
    emoji: '🚀',
    description: 'We\'re always building. Check back for new apps from Weegix.',
  ),
];

const List<Map<String, String>> _services = [
  {'icon': '🔧', 'title': 'IBM Integration Engineering', 'desc': 'ACE, MQ, and DataPower design, build, and stabilization.'},
  {'icon': '📡', 'title': 'Monitoring & Observability', 'desc': 'Real-time visibility across PROD, QA, and TEST environments.'},
  {'icon': '🤖', 'title': 'Agentic AI Integration', 'desc': 'Practical AI agents layered onto real business systems.'},
  {'icon': '🔀', 'title': 'Modernization & Migration', 'desc': 'Moving legacy middleware forward without breaking what works.'},
  {'icon': '📱', 'title': 'Custom Software & Apps', 'desc': 'Purpose-built apps, like this one, from idea to app store.'},
  {'icon': '🎓', 'title': 'AI Training & Enablement', 'desc': 'Hands-on AI tools training for teams and individuals.'},
];

class AboutWeegixScreen extends StatelessWidget {
  const AboutWeegixScreen({super.key});

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _WeegixColors.bg,
      appBar: AppBar(
        title: const Text('About Weegix'),
        backgroundColor: _WeegixColors.navy,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          _header(),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionTitle('What We Do'),
                const SizedBox(height: 12),
                ..._services.map(_serviceRow),
                const SizedBox(height: 28),
                _sectionTitle('Our Apps & Products'),
                const SizedBox(height: 12),
                ..._portfolio.map(_portfolioCard),
                const SizedBox(height: 28),
                _sectionTitle('Get In Touch'),
                const SizedBox(height: 12),
                _contactRow(Icons.language_rounded, 'weegix.com', () => _open('https://weegix.com')),
                _contactRow(Icons.email_rounded, 'hello@weegix.com', () => _open('mailto:hello@weegix.com')),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.location_on_rounded, size: 18, color: _WeegixColors.textMuted),
                    const SizedBox(width: 8),
                    Text('Based in Chicagoland, IL',
                        style: TextStyle(color: _WeegixColors.textMuted, fontSize: 14)),
                  ],
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _header() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 32, 20, 32),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [_WeegixColors.navy, _WeegixColors.navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Weegix',
                  style: TextStyle(
                      color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
              const SizedBox(width: 8),
              Container(
                width: 10, height: 10,
                decoration: const BoxDecoration(color: _WeegixColors.teal, shape: BoxShape.circle),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            'Enterprise integration, agentic AI, and custom software, engineered to stay up.',
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600, height: 1.4),
          ),
          const SizedBox(height: 14),
          Text(
            'Weegix Technology Solutions designs, stabilizes, and monitors IBM ACE, MQ, and DataPower '
            'messaging for enterprises, then layers in agentic AI and builds purpose-made apps like this one, '
            'for families, learners, and communities.',
            style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 14, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Text(text,
        style: const TextStyle(
            fontSize: 20, fontWeight: FontWeight.w800, color: _WeegixColors.textDark));
  }

  Widget _serviceRow(Map<String, String> s) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(s['icon']!, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s['title']!,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                Text(s['desc']!,
                    style: const TextStyle(color: _WeegixColors.textMuted, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _portfolioCard(PortfolioApp app) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: app.isCurrentApp ? _WeegixColors.teal : Colors.black12,
          width: app.isCurrentApp ? 2 : 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(app.emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(app.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    if (app.isCurrentApp) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: _WeegixColors.teal.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text('You are here',
                            style: TextStyle(
                                fontSize: 10, fontWeight: FontWeight.w700, color: _WeegixColors.teal)),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(app.description,
                    style: const TextStyle(color: _WeegixColors.textMuted, fontSize: 13, height: 1.4)),
                if (app.storeUrl != null) ...[
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () => _open(app.storeUrl!),
                    child: const Row(
                      children: [
                        Icon(Icons.download_rounded, size: 16, color: _WeegixColors.gold),
                        SizedBox(width: 4),
                        Text('Get it on Google Play',
                            style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w700, color: _WeegixColors.gold)),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _contactRow(IconData icon, String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: Row(
          children: [
            Icon(icon, size: 20, color: _WeegixColors.navy),
            const SizedBox(width: 10),
            Text(label,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w600, color: _WeegixColors.navy)),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------------------
// ANDROID SETUP NOTE (do this once per app that includes this screen):
// Add this <queries> block to android/app/src/main/AndroidManifest.xml,
// as a SIBLING of <application> (not nested inside it), or the web/email
// links above will silently do nothing on Android 11+:
//
//   <queries>
//     <intent><action android:name="android.intent.action.VIEW" />
//       <data android:scheme="https" /></intent>
//     <intent><action android:name="android.intent.action.VIEW" />
//       <data android:scheme="mailto" /></intent>
//   </queries>
// ----------------------------------------------------------------------------
