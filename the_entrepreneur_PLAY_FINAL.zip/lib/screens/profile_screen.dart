import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../data/modules_catalog.dart';
import '../data/achievements_data.dart';
import '../services/progress_db.dart';
import 'about_weegix_screen.dart';
import 'achievements_screen.dart';
import 'settings_screen.dart';
import 'idea_lab_screen.dart';
import 'glossary_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  AchievementStats? _stats;
  Set<String> _completed = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final stats = await loadAchievementStats();
    final completed = await ProgressDb.instance.getCompletedLessonIds();
    if (mounted) {
      setState(() {
        _stats = stats;
        _completed = completed;
      });
    }
  }

  Future<void> _open(Widget screen) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final stats = _stats;
    final unlockedBadges = stats == null ? 0 : achievements.where((a) => a.isUnlocked(stats)).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Row(
              children: [
                Expanded(child: _statCard('Current streak', '${stats?.streak ?? 0} days')),
                const SizedBox(width: 10),
                Expanded(child: _statCard('Longest streak', '${stats?.longestStreak ?? 0} days')),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _statCard('Lessons', '${stats?.lessonsDone ?? 0} / ${stats?.totalLessons ?? 0}')),
                const SizedBox(width: 10),
                Expanded(child: _statCard('Ideas saved', '${stats?.ideas ?? 0}')),
              ],
            ),
            const SizedBox(height: 20),
            Text('Progress by module',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(color: AppColors.navy, fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            ...modulesCatalog.map((m) {
              final done = m.lessons.where((l) => _completed.contains(l.id)).length;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    Container(width: 10, height: 10, decoration: BoxDecoration(color: Color(m.colorValue), shape: BoxShape.circle)),
                    const SizedBox(width: 10),
                    Expanded(child: Text(m.title, style: const TextStyle(fontSize: 13, color: AppColors.ink))),
                    Text('$done/${m.lessons.length}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: AppColors.muted)),
                  ],
                ),
              );
            }),
            const SizedBox(height: 18),
            _navTile(
              icon: Icons.emoji_events_rounded,
              title: 'Achievements',
              subtitle: '$unlockedBadges of ${achievements.length} unlocked',
              onTap: () => _open(const AchievementsScreen()),
            ),
            const SizedBox(height: 10),
            _navTile(
              icon: Icons.lightbulb_rounded,
              title: 'Idea Lab',
              subtitle: 'Your saved ideas and scores',
              onTap: () => _open(const IdeaLabScreen()),
            ),
            const SizedBox(height: 10),
            _navTile(
              icon: Icons.menu_book_rounded,
              title: 'Glossary',
              subtitle: 'Plain-language business terms',
              onTap: () => _open(const GlossaryScreen()),
            ),
            const SizedBox(height: 10),
            _navTile(
              icon: Icons.settings_rounded,
              title: 'Settings',
              subtitle: 'Daily reminder and data',
              onTap: () => _open(const SettingsScreen()),
            ),
            const SizedBox(height: 10),
            _navTile(
              icon: Icons.info_outline_rounded,
              title: 'About Weegix',
              subtitle: 'Our other apps and how to reach us',
              onTap: () => _open(const AboutWeegixScreen()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _navTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: ListTile(
        leading: Icon(icon, color: AppColors.navy),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.navy)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
        onTap: onTap,
      ),
    );
  }

  Widget _statCard(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.navy)),
        ],
      ),
    );
  }
}
