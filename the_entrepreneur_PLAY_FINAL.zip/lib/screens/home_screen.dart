import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/module.dart';
import '../models/case_study.dart';
import '../data/modules_catalog.dart';
import '../data/case_studies_data.dart';
import '../services/progress_db.dart';
import '../services/module_navigation.dart';
import 'lesson_screen.dart';
import 'founder_detail_screen.dart';
import 'short_case_detail_screen.dart';
import 'modules_screen.dart';
import 'daily_challenge_screen.dart';
import 'idea_lab_screen.dart';
import 'calculators_screen.dart';
import 'achievements_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _streak = 0;
  Set<String> _completed = {};
  bool _unlocked = false;
  bool _challengeDone = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = ProgressDb.instance;
    final streak = await db.getCurrentStreak();
    final completed = await db.getCompletedLessonIds();
    final unlocked = await db.isUnlocked();
    final challengeDone = await db.isTodayComplete();
    if (!mounted) return;
    setState(() {
      _streak = streak;
      _completed = completed;
      _unlocked = unlocked;
      _challengeDone = challengeDone;
    });
  }

  Future<void> _open(Widget screen) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    _load();
  }

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    // Today's Wave rotates by day across the Technology Wave module.
    final waveModule = modulesCatalog[1];
    final waveLesson = waveModule.lessons[DateTime.now().day % waveModule.lessons.length];

    // Next unfinished lesson in the first module that has one.
    Module? nextModule;
    Lesson? nextLesson;
    for (final m in modulesCatalog) {
      if (!(m.isFree || _unlocked)) continue;
      for (final l in m.lessons) {
        if (!_completed.contains(l.id)) {
          nextModule = m;
          nextLesson = l;
          break;
        }
      }
      if (nextLesson != null) break;
    }

    final Module? nm = nextModule;
    final Lesson? nl = nextLesson;
    final List<DeepFounder> founders = deepFounders;
    final List<ShortCase> cases = shortCases.take(3).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('The Entrepreneur')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(_greeting, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            const SizedBox(height: 2),
            Text("Let's build something.",
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: AppColors.navy)),
            const SizedBox(height: 10),
            if (_streak > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(20)),
                child: Text('$_streak-day streak',
                    style: const TextStyle(color: AppColors.gold, fontSize: 11, fontWeight: FontWeight.w600)),
              ),
            const SizedBox(height: 18),

            // Today's Wave
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(18)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("TODAY'S WAVE",
                      style: TextStyle(color: AppColors.gold, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1)),
                  const SizedBox(height: 8),
                  Text(waveLesson.title,
                      style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600, height: 1.3)),
                  const SizedBox(height: 8),
                  Text(waveLesson.principle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xFFC7CEDB), fontSize: 12.5, height: 1.5)),
                  const SizedBox(height: 14),
                  ElevatedButton(
                    onPressed: () => _open(LessonScreen(module: waveModule, lesson: waveLesson)),
                    child: const Text('Read the wave'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Quick actions
            Row(
              children: [
                _quickAction(
                  icon: _challengeDone ? Icons.check_circle_rounded : Icons.bolt_rounded,
                  label: _challengeDone ? 'Done today' : 'Daily challenge',
                  onTap: () => _open(const DailyChallengeScreen()),
                ),
                const SizedBox(width: 8),
                _quickAction(
                  icon: Icons.lightbulb_rounded,
                  label: 'Idea Lab',
                  onTap: () => _open(const IdeaLabScreen()),
                ),
                const SizedBox(width: 8),
                _quickAction(
                  icon: Icons.calculate_rounded,
                  label: 'Calculators',
                  onTap: () => _open(const CalculatorsScreen()),
                ),
                const SizedBox(width: 8),
                _quickAction(
                  icon: Icons.emoji_events_rounded,
                  label: 'Badges',
                  onTap: () => _open(const AchievementsScreen()),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Continue where you left off
            if (nm != null && nl != null)
              _continueCard(nm, nl)
            else
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.tealLight,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Text(
                  'You finished every lesson. Run your best idea through the Idea Lab scorecard and take the next step.',
                  style: TextStyle(fontSize: 13, height: 1.5, color: AppColors.navy),
                ),
              ),
            const SizedBox(height: 18),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Modules',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(color: AppColors.navy, fontWeight: FontWeight.w600)),
                TextButton(
                  onPressed: () => _open(const ModulesScreen()),
                  child: const Text('See all', style: TextStyle(color: AppColors.teal)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.35,
              children: modulesCatalog.map((m) {
                final done = m.lessons.where((l) => _completed.contains(l.id)).length;
                final total = m.lessons.length;
                final locked = !(m.isFree || _unlocked);
                return GestureDetector(
                  onTap: () async {
                    await ModuleNavigation.openModule(context, m);
                    _load();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(color: Color(m.colorValue), borderRadius: BorderRadius.circular(8)),
                        ),
                        const SizedBox(height: 10),
                        Text(m.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
                        const Spacer(),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: total == 0 ? 0 : done / total,
                            minHeight: 4,
                            backgroundColor: const Color(0xFFEDEAE0),
                            valueColor: const AlwaysStoppedAnimation(AppColors.teal),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(locked ? 'Locked' : '$done / $total lessons',
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 9.5, color: AppColors.muted)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 18),

            Text('Founder stories',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(color: AppColors.navy, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            SizedBox(
              height: 118,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  ...founders.map((f) => _storyCard(
                        kicker: 'DEEP TRACK',
                        title: f.name,
                        subtitle: f.chapters.first.title,
                        onTap: () => _open(FounderDetailScreen(founder: f)),
                      )),
                  ...cases.map((c) => _storyCard(
                        kicker: 'SHORT CASE',
                        title: c.company,
                        subtitle: c.lesson,
                        onTap: () => _open(ShortCaseDetailScreen(shortCase: c)),
                      )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _quickAction({required IconData icon, required String label, required VoidCallback onTap}) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.cardBorder),
          ),
          child: Column(
            children: [
              Icon(icon, color: AppColors.teal, size: 22),
              const SizedBox(height: 6),
              Text(label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _continueCard(Module module, Lesson lesson) {
    return GestureDetector(
      onTap: () => _open(LessonScreen(module: module, lesson: lesson)),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: Color(module.colorValue), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.play_arrow_rounded, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('CONTINUE LEARNING',
                      style: TextStyle(fontFamily: 'monospace', fontSize: 9.5, color: AppColors.teal, letterSpacing: 0.8)),
                  const SizedBox(height: 3),
                  Text(lesson.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
                  Text(module.title, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
          ],
        ),
      ),
    );
  }

  Widget _storyCard({
    required String kicker,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 150,
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(kicker,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 9, color: AppColors.teal, letterSpacing: 0.5)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
            const SizedBox(height: 4),
            Text(subtitle,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 10.5, color: AppColors.muted, height: 1.4)),
          ],
        ),
      ),
    );
  }
}
