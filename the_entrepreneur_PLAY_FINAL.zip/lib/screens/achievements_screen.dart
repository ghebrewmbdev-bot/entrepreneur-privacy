import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../data/achievements_data.dart';

class AchievementsScreen extends StatefulWidget {
  const AchievementsScreen({super.key});

  @override
  State<AchievementsScreen> createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen> {
  AchievementStats? _stats;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final stats = await loadAchievementStats();
    if (mounted) setState(() => _stats = stats);
  }

  @override
  Widget build(BuildContext context) {
    final stats = _stats;
    if (stats == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Achievements')),
        body: const Center(child: CircularProgressIndicator(color: AppColors.teal)),
      );
    }
    final unlockedCount = achievements.where((a) => a.isUnlocked(stats)).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Achievements')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(16)),
            child: Row(
              children: [
                const Icon(Icons.emoji_events_rounded, color: AppColors.gold, size: 34),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('$unlockedCount of ${achievements.length} unlocked',
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text('Longest streak: ${stats.longestStreak} days',
                          style: const TextStyle(color: Color(0xFFC7CEDB), fontSize: 12.5)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ...achievements.map((a) {
            final unlocked = a.isUnlocked(stats);
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: unlocked ? AppColors.teal : AppColors.cardBorder, width: unlocked ? 1.5 : 1),
              ),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: unlocked ? AppColors.gold : const Color(0xFFEDEAE0),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(a.icon, color: unlocked ? AppColors.navy : const Color(0xFFB3B0A2)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.title,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: unlocked ? AppColors.navy : AppColors.muted,
                            )),
                        const SizedBox(height: 2),
                        Text(a.description, style: const TextStyle(fontSize: 12, color: AppColors.muted, height: 1.4)),
                      ],
                    ),
                  ),
                  if (unlocked) const Icon(Icons.check_circle_rounded, color: AppColors.teal),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
