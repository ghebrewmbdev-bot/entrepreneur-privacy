import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

double _num(TextEditingController c) => double.tryParse(c.text.trim()) ?? 0;

String _commas(String s) {
  final neg = s.startsWith('-');
  final digits = neg ? s.substring(1) : s;
  final parts = digits.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (int i = 0; i < intPart.length; i++) {
    if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(',');
    buf.write(intPart[i]);
  }
  final out = parts.length > 1 ? '${buf.toString()}.${parts[1]}' : buf.toString();
  return neg ? '-$out' : out;
}

String _money(double v) {
  if (v.isNaN || v.isInfinite) return '-';
  return '\$${_commas(v.toStringAsFixed(2))}';
}

String _plain(double v, {int decimals = 1}) {
  if (v.isNaN || v.isInfinite) return '-';
  return _commas(v.toStringAsFixed(decimals));
}

class CalculatorsScreen extends StatelessWidget {
  const CalculatorsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Calculators'),
          bottom: const TabBar(
            indicatorColor: AppColors.gold,
            labelColor: Colors.white,
            unselectedLabelColor: Color(0xFFAAB4C8),
            tabs: [Tab(text: 'Unit economics'), Tab(text: 'Break-even')],
          ),
        ),
        body: const TabBarView(
          children: [_UnitEconomicsTab(), _BreakEvenTab()],
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final VoidCallback onChanged;
  const _Field({required this.label, required this.hint, required this.controller, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        onChanged: (_) => onChanged(),
        decoration: InputDecoration(
          labelText: label,
          helperText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.cardBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.cardBorder),
          ),
        ),
      ),
    );
  }
}

class _ResultRow extends StatelessWidget {
  final String label;
  final String value;
  const _ResultRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Color(0xFFC7CEDB), fontSize: 13))),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _UnitEconomicsTab extends StatefulWidget {
  const _UnitEconomicsTab();

  @override
  State<_UnitEconomicsTab> createState() => _UnitEconomicsTabState();
}

class _UnitEconomicsTabState extends State<_UnitEconomicsTab> {
  final _arpu = TextEditingController(text: '20');
  final _margin = TextEditingController(text: '80');
  final _churn = TextEditingController(text: '5');
  final _cac = TextEditingController(text: '60');

  @override
  void dispose() {
    _arpu.dispose();
    _margin.dispose();
    _churn.dispose();
    _cac.dispose();
    super.dispose();
  }

  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final arpu = _num(_arpu);
    final margin = _num(_margin) / 100;
    final churn = _num(_churn) / 100;
    final cac = _num(_cac);

    final monthlyProfit = arpu * margin;
    final lifetimeMonths = churn > 0 ? 1 / churn : double.nan;
    final ltv = churn > 0 ? monthlyProfit / churn : double.nan;
    final ratio = (cac > 0 && !ltv.isNaN) ? ltv / cac : double.nan;
    final payback = monthlyProfit > 0 ? cac / monthlyProfit : double.nan;

    String verdict;
    if (ratio.isNaN) {
      verdict = 'Fill in every field to see the verdict. Churn and CAC must be above zero.';
    } else if (ratio >= 3) {
      verdict = 'Healthy. Each customer returns 3x or more of what it costs to win them.';
    } else if (ratio >= 1) {
      verdict = 'Thin. You earn back the cost but with little room. Improve retention, price, or CAC.';
    } else {
      verdict = 'You lose money on each customer. Fix this before spending on growth.';
    }
    if (!payback.isNaN && payback > 12) {
      verdict = '$verdict Payback is longer than a year, which strains cash.';
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _Field(label: 'Revenue per customer, per month (\$)', hint: 'Average monthly revenue per customer', controller: _arpu, onChanged: _refresh),
        _Field(label: 'Gross margin (%)', hint: 'Share of revenue left after direct costs', controller: _margin, onChanged: _refresh),
        _Field(label: 'Monthly churn (%)', hint: 'Share of customers who leave each month', controller: _churn, onChanged: _refresh),
        _Field(label: 'Customer acquisition cost (\$)', hint: 'Total sales and marketing spend per new customer', controller: _cac, onChanged: _refresh),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(16)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _ResultRow('Monthly profit per customer', _money(monthlyProfit)),
              _ResultRow('Average customer lifetime', '${_plain(lifetimeMonths)} months'),
              _ResultRow('Lifetime value (LTV)', _money(ltv)),
              _ResultRow('LTV to CAC ratio', ratio.isNaN ? '-' : '${_plain(ratio)}x'),
              _ResultRow('CAC payback', payback.isNaN ? '-' : '${_plain(payback)} months'),
              const Divider(color: Color(0xFF2A3B5C), height: 22),
              Text(verdict, style: const TextStyle(color: Color(0xFFDCE1EC), fontSize: 13, height: 1.5)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'Rule of thumb: aim for an LTV to CAC ratio of 3x or higher, with payback inside 12 months.',
          style: TextStyle(fontSize: 12, color: AppColors.muted, height: 1.5),
        ),
      ],
    );
  }
}

class _BreakEvenTab extends StatefulWidget {
  const _BreakEvenTab();

  @override
  State<_BreakEvenTab> createState() => _BreakEvenTabState();
}

class _BreakEvenTabState extends State<_BreakEvenTab> {
  final _fixed = TextEditingController(text: '3000');
  final _price = TextEditingController(text: '50');
  final _variable = TextEditingController(text: '20');

  @override
  void dispose() {
    _fixed.dispose();
    _price.dispose();
    _variable.dispose();
    super.dispose();
  }

  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final fixed = _num(_fixed);
    final price = _num(_price);
    final variable = _num(_variable);
    final contribution = price - variable;
    final units = contribution > 0 ? (fixed / contribution).ceilToDouble() : double.nan;
    final revenue = units.isNaN ? double.nan : units * price;
    final perDay = units.isNaN ? double.nan : units / 30;

    String verdict;
    if (contribution <= 0) {
      verdict = 'Each sale loses money. Raise the price or cut the cost per sale.';
    } else {
      verdict = 'You need about ${_plain(units, decimals: 0)} sales a month, roughly ${_plain(perDay)} per day, to cover your fixed costs.';
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _Field(label: 'Fixed costs per month (\$)', hint: 'Rent, tools, salaries, anything that does not change with sales', controller: _fixed, onChanged: _refresh),
        _Field(label: 'Price per sale (\$)', hint: 'What one customer pays', controller: _price, onChanged: _refresh),
        _Field(label: 'Variable cost per sale (\$)', hint: 'What each sale costs you directly', controller: _variable, onChanged: _refresh),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(16)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _ResultRow('Profit per sale', _money(contribution)),
              _ResultRow('Break-even sales per month', units.isNaN ? '-' : _plain(units, decimals: 0)),
              _ResultRow('Break-even revenue per month', _money(revenue)),
              const Divider(color: Color(0xFF2A3B5C), height: 22),
              Text(verdict, style: const TextStyle(color: Color(0xFFDCE1EC), fontSize: 13, height: 1.5)),
            ],
          ),
        ),
      ],
    );
  }
}
