import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/module.dart';
import '../services/progress_db.dart';
import 'lesson_screen.dart';
import 'quiz_screen.dart';
import '../data/quizzes_data.dart';

class LessonListScreen extends StatefulWidget {
  final Module module;
  const LessonListScreen({super.key, required this.module});

  @override
  State<LessonListScreen> createState() => _LessonListScreenState();
}

class _LessonListScreenState extends State<LessonListScreen> {
  Set<String> _completed = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final completed = await ProgressDb.instance.getCompletedLessonIds();
    if (mounted) setState(() => _completed = completed);
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.module;
    return Scaffold(
      appBar: AppBar(title: Text(m.title)),
      body: ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: m.lessons.length + (moduleQuizzes.containsKey(m.id) ? 1 : 0),
        itemBuilder: (context, i) {
          if (i == m.lessons.length) {
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: AppColors.navy,
                borderRadius: BorderRadius.circular(14),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                leading: const CircleAvatar(
                  backgroundColor: AppColors.gold,
                  child: Icon(Icons.quiz_rounded, size: 18, color: AppColors.navy),
                ),
                title: const Text('Module quiz', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5, color: Colors.white)),
                subtitle: const Text('Check what you learned', style: TextStyle(fontSize: 12, color: Color(0xFFC7CEDB))),
                trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white70),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => QuizScreen(module: m))),
              ),
            );
          }
          final lesson = m.lessons[i];
          final done = _completed.contains(lesson.id);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.cardBorder),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              leading: CircleAvatar(
                backgroundColor: done ? AppColors.teal : Color(m.colorValue).withOpacity(0.15),
                child: Icon(done ? Icons.check : Icons.menu_book_rounded, size: 18, color: done ? Colors.white : Color(m.colorValue)),
              ),
              title: Text('Lesson ${i + 1}: ${lesson.title}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5, color: AppColors.navy)),
              trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
              onTap: () async {
                await Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonScreen(module: m, lesson: lesson)));
                _load();
              },
            ),
          );
        },
      ),
    );
  }
}
