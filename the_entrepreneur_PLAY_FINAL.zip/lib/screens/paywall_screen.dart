import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/progress_db.dart';
import '../services/purchase_service.dart';

// Dormant while all modules are free. Reached only if a module is set to
// isFree: false in modules_catalog.dart. Requires the product
// com.weegix.entrepreneur.unlock_all to exist and be active in Play Console.

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});

  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> {
  bool _loading = true;
  String _priceLabel = '\$4.99';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await PurchaseService.instance.init();
    if (PurchaseService.instance.products.isNotEmpty) {
      _priceLabel = PurchaseService.instance.products.first.price;
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _buy() async {
    if (!PurchaseService.instance.storeAvailable || PurchaseService.instance.products.isEmpty) {
      // Dev-only fallback so the app stays testable before the store product exists.
      await ProgressDb.instance.setUnlocked(true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Store unavailable, unlocked locally for testing')),
        );
        Navigator.of(context).pop();
      }
      return;
    }
    await PurchaseService.instance.buyUnlockAll();
  }

  Future<void> _restore() async {
    await PurchaseService.instance.restorePurchases();
    final unlocked = await ProgressDb.instance.isUnlocked();
    if (mounted && unlocked) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Purchase restored')));
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.lock_open_rounded, color: AppColors.gold, size: 40),
              const SizedBox(height: 20),
              const Text('Unlock premium modules',
                  style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              const Text(
                'Get full access to every premium module in The Entrepreneur, plus every future module we add.',
                style: TextStyle(color: Color(0xFFC7CEDB), fontSize: 14, height: 1.6),
              ),
              const SizedBox(height: 28),
              if (_loading)
                const Center(child: CircularProgressIndicator(color: AppColors.gold))
              else ...[
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _buy,
                    child: Text('Unlock all modules, $_priceLabel'),
                  ),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: _restore,
                  child: const Text('Restore purchases', style: TextStyle(color: Color(0xFFAAB4C8))),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Not now', style: TextStyle(color: Color(0xFFAAB4C8))),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
