import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../data/case_studies_data.dart';
import 'founder_detail_screen.dart';
import 'short_case_detail_screen.dart';

class StoriesScreen extends StatelessWidget {
  const StoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Founder Stories'),
          bottom: const TabBar(
            indicatorColor: AppColors.gold,
            labelColor: Colors.white,
            unselectedLabelColor: Color(0xFFAAB4C8),
            tabs: [Tab(text: 'Deep Track'), Tab(text: 'Short Track')],
          ),
        ),
        body: TabBarView(
          children: [
            ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: deepFounders.length,
              itemBuilder: (context, i) {
                final f = deepFounders[i];
                return _card(
                  context,
                  title: f.name,
                  subtitle: '${f.company}, ${f.chapters.length} chapters',
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => FounderDetailScreen(founder: f))),
                );
              },
            ),
            ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: shortCases.length,
              itemBuilder: (context, i) {
                final c = shortCases[i];
                return _card(
                  context,
                  title: c.company,
                  subtitle: c.lesson,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ShortCaseDetailScreen(shortCase: c))),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, {required String title, required String subtitle, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.cardBorder)),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.navy)),
                  const SizedBox(height: 4),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.muted, height: 1.4)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
          ],
        ),
      ),
    );
  }
}
