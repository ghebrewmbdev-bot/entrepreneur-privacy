import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/idea.dart';
import '../services/progress_db.dart';

class IdeaEditScreen extends StatefulWidget {
  final Idea? idea;
  const IdeaEditScreen({super.key, this.idea});

  @override
  State<IdeaEditScreen> createState() => _IdeaEditScreenState();
}

class _IdeaEditScreenState extends State<IdeaEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _problem;
  late final TextEditingController _customer;
  late final TextEditingController _solution;
  late final TextEditingController _notes;
  String _status = 'Spark';
  double _pain = 3;
  double _market = 3;
  double _timing = 3;
  double _reach = 3;

  @override
  void initState() {
    super.initState();
    final i = widget.idea;
    _title = TextEditingController(text: i?.title ?? '');
    _problem = TextEditingController(text: i?.problem ?? '');
    _customer = TextEditingController(text: i?.customer ?? '');
    _solution = TextEditingController(text: i?.solution ?? '');
    _notes = TextEditingController(text: i?.notes ?? '');
    if (i != null) {
      _status = i.status;
      _pain = i.pain.toDouble();
      _market = i.market.toDouble();
      _timing = i.timing.toDouble();
      _reach = i.reach.toDouble();
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _problem.dispose();
    _customer.dispose();
    _solution.dispose();
    _notes.dispose();
    super.dispose();
  }

  int get _score => ((_pain + _market + _timing + _reach) / 20 * 100).round();

  String get _weakest {
    final ratings = {'Pain': _pain, 'Market size': _market, 'Timing': _timing, 'Reach': _reach};
    String key = 'Pain';
    double low = _pain;
    ratings.forEach((k, v) {
      if (v < low) {
        low = v;
        key = k;
      }
    });
    return key;
  }

  String get _verdict {
    final s = _score;
    if (s >= 75) {
      return 'Strong spark. Run a smoke test this week.';
    }
    if (s >= 50) {
      return 'Promising. Validate your weakest score first: $_weakest.';
    }
    return 'Weak for now. Revisit the problem or the customer, starting with $_weakest.';
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final now = DateTime.now();
    final old = widget.idea;
    final idea = Idea(
      id: old?.id,
      title: _title.text.trim(),
      problem: _problem.text.trim(),
      customer: _customer.text.trim(),
      solution: _solution.text.trim(),
      notes: _notes.text.trim(),
      status: _status,
      pain: _pain.round(),
      market: _market.round(),
      timing: _timing.round(),
      reach: _reach.round(),
      createdAt: old?.createdAt ?? now,
      updatedAt: now,
    );
    await ProgressDb.instance.saveIdea(idea);
    if (mounted) Navigator.of(context).pop(true);
  }

  Future<void> _delete() async {
    final id = widget.idea?.id;
    if (id == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete this idea?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await ProgressDb.instance.deleteIdea(id);
      if (mounted) Navigator.of(context).pop(true);
    }
  }

  InputDecoration _dec(String label, String hint) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      alignLabelWithHint: true,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.cardBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.cardBorder),
      ),
    );
  }

  Widget _ratingRow(String label, String hint, double value, ValueChanged<double> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.navy)),
            ),
            Text('${value.round()} / 5',
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: AppColors.teal)),
          ],
        ),
        Text(hint, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
        Slider(
          value: value,
          min: 1,
          max: 5,
          divisions: 4,
          activeColor: AppColors.teal,
          onChanged: onChanged,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.idea != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? 'Edit idea' : 'New idea'),
        actions: [
          if (editing)
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded),
              onPressed: _delete,
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextFormField(
              controller: _title,
              textCapitalization: TextCapitalization.sentences,
              decoration: _dec('Idea name', 'A short working name'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Give your idea a name' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _problem,
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
              decoration: _dec('The problem', '[Specific group] struggle with [problem] because [cause]'),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _customer,
              maxLines: 2,
              textCapitalization: TextCapitalization.sentences,
              decoration: _dec('First customer', 'One narrow group you could serve first'),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _solution,
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
              decoration: _dec('The solution', 'The smallest thing that solves it'),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _notes,
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
              decoration: _dec('Notes', 'Interviews, tests, next steps'),
            ),
            const SizedBox(height: 20),
            const Text('STAGE',
                style: TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: AppColors.teal, letterSpacing: 1)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ideaStatuses.map((s) {
                return ChoiceChip(
                  label: Text(s),
                  selected: _status == s,
                  selectedColor: AppColors.tealLight,
                  onSelected: (_) => setState(() => _status = s),
                );
              }).toList(),
            ),
            const SizedBox(height: 22),
            const Text('OPPORTUNITY SCORECARD',
                style: TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: AppColors.teal, letterSpacing: 1)),
            const SizedBox(height: 8),
            _ratingRow('Pain', 'How badly do people need this fixed?', _pain, (v) => setState(() => _pain = v)),
            _ratingRow('Market size', 'How many people share this problem?', _market, (v) => setState(() => _market = v)),
            _ratingRow('Timing', 'Is now the right moment (new tech, new behavior)?', _timing, (v) => setState(() => _timing = v)),
            _ratingRow('Reach', 'Can you get this in front of your first 100 customers?', _reach, (v) => setState(() => _reach = v)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(14)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('SCORE',
                          style: TextStyle(fontFamily: 'monospace', fontSize: 10, color: AppColors.gold, letterSpacing: 1)),
                      const Spacer(),
                      Text('$_score / 100',
                          style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(_verdict, style: const TextStyle(color: Color(0xFFC7CEDB), fontSize: 13, height: 1.5)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _save,
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
                child: const Text('Save idea'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
