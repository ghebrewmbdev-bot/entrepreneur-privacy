import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../data/modules_catalog.dart';
import '../data/case_studies_data.dart';
import '../data/toolkit_data.dart';
import '../data/glossary_data.dart';
import 'glossary_screen.dart';
import '../models/module.dart';
import '../services/module_navigation.dart';
import 'lesson_screen.dart';
import 'founder_detail_screen.dart';
import 'short_case_detail_screen.dart';
import 'toolkit_screen.dart';

class _Hit {
  final String kind;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _Hit({required this.kind, required this.title, required this.subtitle, required this.onTap});
}

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  List<_Hit> _hits = [];
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _openLesson(Module m, Lesson l) {
    if (m.isFree) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonScreen(module: m, lesson: l)));
    } else {
      ModuleNavigation.openModule(context, m);
    }
  }

  List<_Hit> _search(String q) {
    final query = q.trim().toLowerCase();
    if (query.length < 2) return [];
    final hits = <_Hit>[];

    for (final m in modulesCatalog) {
      for (final l in m.lessons) {
        final hay = '${l.title} ${l.principle} ${l.story} ${l.bestPractices.join(' ')} ${l.reflection}'.toLowerCase();
        if (hay.contains(query)) {
          hits.add(_Hit(
            kind: 'LESSON',
            title: l.title,
            subtitle: m.title,
            onTap: () => _openLesson(m, l),
          ));
        }
      }
    }

    for (final f in deepFounders) {
      for (final ch in f.chapters) {
        final hay = '${f.name} ${f.company} ${ch.title} ${ch.content}'.toLowerCase();
        if (hay.contains(query)) {
          hits.add(_Hit(
            kind: 'FOUNDER',
            title: '${f.name}, chapter ${ch.number}',
            subtitle: ch.title,
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => FounderDetailScreen(founder: f))),
          ));
        }
      }
    }

    for (final c in shortCases) {
      final hay = '${c.company} ${c.story} ${c.lesson}'.toLowerCase();
      if (hay.contains(query)) {
        hits.add(_Hit(
          kind: 'CASE',
          title: c.company,
          subtitle: c.lesson,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ShortCaseDetailScreen(shortCase: c))),
        ));
      }
    }

    for (final t in toolkitItems) {
      final hay = '${t.title} ${t.content}'.toLowerCase();
      if (hay.contains(query)) {
        hits.add(_Hit(
          kind: 'TOOLKIT',
          title: t.title,
          subtitle: t.category,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ToolkitScreen())),
        ));
      }
    }

    for (final g in glossaryTerms) {
      final hay = '${g.term} ${g.definition}'.toLowerCase();
      if (hay.contains(query)) {
        hits.add(_Hit(
          kind: 'GLOSSARY',
          title: g.term,
          subtitle: g.definition,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GlossaryScreen())),
        ));
      }
    }

    return hits.length > 50 ? hits.sublist(0, 50) : hits;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: TextField(
              controller: _controller,
              autofocus: true,
              textInputAction: TextInputAction.search,
              onChanged: (v) => setState(() {
                _query = v;
                _hits = _search(v);
              }),
              decoration: InputDecoration(
                hintText: 'Search lessons, founders, tools, terms',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.cardBorder),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.cardBorder),
                ),
              ),
            ),
          ),
          Expanded(
            child: _query.trim().length < 2
                ? const Center(
                    child: Text('Type at least 2 letters to search.',
                        style: TextStyle(color: AppColors.muted, fontSize: 13)),
                  )
                : _hits.isEmpty
                    ? const Center(
                        child: Text('No matches. Try a different word.',
                            style: TextStyle(color: AppColors.muted, fontSize: 13)),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                        itemCount: _hits.length,
                        itemBuilder: (context, i) {
                          final h = _hits[i];
                          return GestureDetector(
                            onTap: h.onTap,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: AppColors.cardBorder),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(h.kind,
                                      style: const TextStyle(
                                          fontFamily: 'monospace', fontSize: 9.5, color: AppColors.teal, letterSpacing: 0.8)),
                                  const SizedBox(height: 4),
                                  Text(h.title,
                                      style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
                                  const SizedBox(height: 2),
                                  Text(h.subtitle,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
