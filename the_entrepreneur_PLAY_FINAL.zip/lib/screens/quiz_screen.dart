import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/module.dart';
import '../models/quiz.dart';
import '../data/quizzes_data.dart';
import '../services/progress_db.dart';

class QuizScreen extends StatefulWidget {
  final Module module;
  const QuizScreen({super.key, required this.module});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final List<QuizQuestion> _questions;
  int _index = 0;
  int _score = 0;
  int? _picked;
  bool _finished = false;
  List<int>? _best;

  @override
  void initState() {
    super.initState();
    _questions = moduleQuizzes[widget.module.id] ?? const <QuizQuestion>[];
    _loadBest();
  }

  Future<void> _loadBest() async {
    final scores = await ProgressDb.instance.getQuizScores();
    if (mounted) setState(() => _best = scores[widget.module.id]);
  }

  void _pick(int i) {
    if (_picked != null) return;
    setState(() {
      _picked = i;
      if (i == _questions[_index].answer) _score++;
    });
  }

  Future<void> _next() async {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _picked = null;
      });
    } else {
      await ProgressDb.instance.saveQuizScore(widget.module.id, _score, _questions.length);
      await _loadBest();
      if (mounted) setState(() => _finished = true);
    }
  }

  void _restart() {
    setState(() {
      _index = 0;
      _score = 0;
      _picked = null;
      _finished = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.module.title} quiz')),
      body: _questions.isEmpty
          ? const Center(child: Text('No quiz for this module yet.'))
          : _finished
              ? _result()
              : _question(),
    );
  }

  Widget _question() {
    final q = _questions[_index];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('QUESTION ${_index + 1} OF ${_questions.length}',
            style: const TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: AppColors.teal, letterSpacing: 1)),
        const SizedBox(height: 10),
        Text(q.prompt,
            style: const TextStyle(fontSize: 16, height: 1.45, fontWeight: FontWeight.w600, color: AppColors.navy)),
        const SizedBox(height: 16),
        ...List.generate(q.options.length, (i) {
          Color border = AppColors.cardBorder;
          Color fill = Colors.white;
          if (_picked != null) {
            if (i == q.answer) {
              border = AppColors.teal;
              fill = AppColors.tealLight;
            } else if (i == _picked) {
              border = const Color(0xFFE24B4A);
              fill = const Color(0xFFFBE9E9);
            }
          }
          return GestureDetector(
            onTap: () => _pick(i),
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: fill,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: border, width: 1.4),
              ),
              child: Text(q.options[i], style: const TextStyle(fontSize: 13.5, height: 1.4, color: AppColors.ink)),
            ),
          );
        }),
        if (_picked != null) ...[
          const SizedBox(height: 6),
          Text(
            _picked == q.answer ? 'Correct.' : 'Not quite.',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: _picked == q.answer ? AppColors.teal : const Color(0xFFE24B4A),
            ),
          ),
          const SizedBox(height: 4),
          Text(q.explanation, style: const TextStyle(fontSize: 13, height: 1.5, color: AppColors.ink)),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _next,
              child: Text(_index + 1 < _questions.length ? 'Next question' : 'See my score'),
            ),
          ),
        ],
      ],
    );
  }

  Widget _result() {
    final total = _questions.length;
    final perfect = _score == total;
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SizedBox(height: 20),
        Icon(perfect ? Icons.stars_rounded : Icons.emoji_events_rounded, size: 56, color: AppColors.gold),
        const SizedBox(height: 14),
        Text('You scored $_score of $total',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.navy)),
        const SizedBox(height: 8),
        Text(
          perfect ? 'Perfect. You have this module down.' : 'Review the lessons and try again to beat your score.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 13.5, color: AppColors.muted, height: 1.5),
        ),
        if (_best != null) ...[
          const SizedBox(height: 6),
          Text('Your best: ${_best![0]} of ${_best![1]}',
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 12.5, color: AppColors.teal)),
        ],
        const SizedBox(height: 24),
        ElevatedButton(onPressed: _restart, child: const Text('Try again')),
        const SizedBox(height: 10),
        OutlinedButton(
          onPressed: () => Navigator.of(context).pop(),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.navy,
            side: const BorderSide(color: AppColors.navy),
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
          child: const Text('Back to lessons'),
        ),
      ],
    );
  }
}
