import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../data/modules_catalog.dart';
import '../services/progress_db.dart';
import '../services/module_navigation.dart';
import 'search_screen.dart';

class ModulesScreen extends StatefulWidget {
  const ModulesScreen({super.key});

  @override
  State<ModulesScreen> createState() => _ModulesScreenState();
}

class _ModulesScreenState extends State<ModulesScreen> {
  Set<String> _completed = {};
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final completed = await ProgressDb.instance.getCompletedLessonIds();
    final unlocked = await ProgressDb.instance.isUnlocked();
    if (mounted) {
      setState(() {
        _completed = completed;
        _unlocked = unlocked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Modules'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: modulesCatalog.length,
          itemBuilder: (context, i) {
            final m = modulesCatalog[i];
            final done = m.lessons.where((l) => _completed.contains(l.id)).length;
            final total = m.lessons.length;
            final locked = !(m.isFree || _unlocked);
            return GestureDetector(
              onTap: () async {
                await ModuleNavigation.openModule(context, m);
                _load();
              },
              child: Opacity(
                opacity: locked ? 0.75 : 1.0,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.cardBorder),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(color: Color(m.colorValue), borderRadius: BorderRadius.circular(10)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${m.number}. ${m.title}',
                                style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
                            const SizedBox(height: 3),
                            Text(m.description,
                                style: const TextStyle(fontSize: 11.5, color: AppColors.muted, height: 1.4)),
                            const SizedBox(height: 8),
                            if (!locked)
                              Row(
                                children: [
                                  Expanded(
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(4),
                                      child: LinearProgressIndicator(
                                        value: total == 0 ? 0 : done / total,
                                        minHeight: 4,
                                        backgroundColor: const Color(0xFFEDEAE0),
                                        valueColor: const AlwaysStoppedAnimation(AppColors.teal),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Text('$done/$total',
                                      style: const TextStyle(
                                          fontFamily: 'monospace', fontSize: 9.5, color: Color(0xFF9A9788))),
                                ],
                              )
                            else
                              const Text('LOCKED, unlock all modules',
                                  style: TextStyle(fontFamily: 'monospace', fontSize: 9.5, color: Color(0xFF9A9788))),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
