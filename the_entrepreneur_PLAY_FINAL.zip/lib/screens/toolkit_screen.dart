import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import '../data/toolkit_data.dart';
import 'idea_lab_screen.dart';
import 'calculators_screen.dart';

class ToolkitScreen extends StatelessWidget {
  const ToolkitScreen({super.key});

  Widget _toolCard(BuildContext context, {required IconData icon, required String title, required String subtitle, required Widget screen}) {
    return Expanded(
      child: GestureDetector(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen)),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.navy,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: AppColors.gold, size: 26),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 3),
              Text(subtitle, style: const TextStyle(color: Color(0xFFC7CEDB), fontSize: 11.5, height: 1.4)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categories = toolkitItems.map((t) => t.category).toSet().toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Toolkit')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            children: [
              _toolCard(
                context,
                icon: Icons.lightbulb_rounded,
                title: 'Idea Lab',
                subtitle: 'Save and score your ideas',
                screen: const IdeaLabScreen(),
              ),
              const SizedBox(width: 10),
              _toolCard(
                context,
                icon: Icons.calculate_rounded,
                title: 'Calculators',
                subtitle: 'Unit economics and break-even',
                screen: const CalculatorsScreen(),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ...categories.map((cat) {
            final items = toolkitItems.where((t) => t.category == cat).toList();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, top: 6),
                  child: Text(cat,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.navy)),
                ),
                ...items.map((item) => Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.cardBorder),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.title,
                              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.navy)),
                          const SizedBox(height: 6),
                          Text(item.content, style: const TextStyle(fontSize: 12.5, height: 1.5, color: AppColors.ink)),
                          const SizedBox(height: 8),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton.icon(
                              onPressed: () {
                                Clipboard.setData(ClipboardData(text: item.content));
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Copied to clipboard'), duration: Duration(seconds: 1)),
                                );
                              },
                              icon: const Icon(Icons.copy_rounded, size: 15, color: AppColors.teal),
                              label: const Text('Copy', style: TextStyle(color: AppColors.teal, fontSize: 12)),
                            ),
                          ),
                        ],
                      ),
                    )),
                const SizedBox(height: 10),
              ],
            );
          }),
        ],
      ),
    );
  }
}
