import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/idea.dart';
import '../services/progress_db.dart';
import 'idea_edit_screen.dart';

class IdeaLabScreen extends StatefulWidget {
  const IdeaLabScreen({super.key});

  @override
  State<IdeaLabScreen> createState() => _IdeaLabScreenState();
}

class _IdeaLabScreenState extends State<IdeaLabScreen> {
  List<Idea> _ideas = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final ideas = await ProgressDb.instance.getIdeas();
    if (mounted) {
      setState(() {
        _ideas = ideas;
        _loading = false;
      });
    }
  }

  Future<void> _open(Idea? idea) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => IdeaEditScreen(idea: idea)),
    );
    _load();
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Validating':
        return const Color(0xFF378ADD);
      case 'Building':
        return const Color(0xFF7F77DD);
      case 'Launched':
        return AppColors.teal;
      case 'Parked':
        return const Color(0xFF9A9788);
      default:
        return AppColors.gold;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Idea Lab')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(null),
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.navy,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New idea'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.teal))
          : _ideas.isEmpty
              ? _empty()
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 90),
                  itemCount: _ideas.length,
                  itemBuilder: (context, i) => _card(_ideas[i]),
                ),
    );
  }

  Widget _empty() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lightbulb_outline_rounded, size: 52, color: AppColors.gold),
            const SizedBox(height: 16),
            const Text('Your idea lab is empty',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.navy)),
            const SizedBox(height: 8),
            const Text(
              'Capture an idea, describe the problem and first customer, then score it. Start with the friction you noticed today.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13.5, color: AppColors.muted, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(Idea idea) {
    final color = _statusColor(idea.status);
    return GestureDetector(
      onTap: () => _open(idea),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(idea.title,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.navy)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(idea.status,
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color)),
                ),
              ],
            ),
            if (idea.problem.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(idea.problem,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12.5, color: AppColors.muted, height: 1.4)),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: idea.score / 100,
                      minHeight: 5,
                      backgroundColor: const Color(0xFFEDEAE0),
                      valueColor: const AlwaysStoppedAnimation(AppColors.teal),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text('Score ${idea.score}',
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: AppColors.muted)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
