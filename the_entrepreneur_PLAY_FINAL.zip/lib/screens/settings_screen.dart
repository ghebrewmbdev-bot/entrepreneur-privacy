import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/notification_service.dart';
import '../services/progress_db.dart';
import 'about_weegix_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _enabled = false;
  TimeOfDay _time = const TimeOfDay(hour: 8, minute: 0);
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await NotificationService.instance.getReminder();
    if (mounted) {
      setState(() {
        _enabled = r.enabled;
        _time = TimeOfDay(hour: r.hour, minute: r.minute);
        _loading = false;
      });
    }
  }

  Future<void> _toggle(bool value) async {
    if (value) {
      final ok = await NotificationService.instance.requestPermission();
      if (!ok) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Notifications are blocked. Allow them in your phone settings to get reminders.')),
          );
        }
        return;
      }
    }
    await NotificationService.instance.setReminder(value, _time.hour, _time.minute);
    if (mounted) setState(() => _enabled = value);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _time);
    if (picked == null) return;
    setState(() => _time = picked);
    if (_enabled) {
      await NotificationService.instance.setReminder(true, picked.hour, picked.minute);
    }
  }

  Future<void> _reset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset learning progress?'),
        content: const Text('This clears completed lessons and your challenge streak. Your saved ideas are kept.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Reset')),
        ],
      ),
    );
    if (ok == true) {
      await ProgressDb.instance.resetLearningProgress();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Progress reset')));
      }
    }
  }

  Widget _section(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 8),
      child: Text(text,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 10.5, color: AppColors.teal, letterSpacing: 1)),
    );
  }

  Widget _box(Widget child) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.teal))
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _section('DAILY REMINDER'),
                _box(
                  Column(
                    children: [
                      SwitchListTile(
                        value: _enabled,
                        onChanged: _toggle,
                        activeColor: AppColors.teal,
                        title: const Text('Remind me every day',
                            style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.navy)),
                        subtitle: const Text('A gentle nudge to do your daily challenge. Scheduled on this phone only.',
                            style: TextStyle(fontSize: 12)),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        enabled: _enabled,
                        title: const Text('Reminder time'),
                        trailing: Text(_time.format(context),
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: _enabled ? AppColors.teal : AppColors.muted,
                            )),
                        onTap: _enabled ? _pickTime : null,
                      ),
                    ],
                  ),
                ),
                _section('ABOUT'),
                _box(
                  ListTile(
                    leading: const Icon(Icons.info_outline_rounded, color: AppColors.navy),
                    title: const Text('About Weegix', style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.navy)),
                    trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutWeegixScreen())),
                  ),
                ),
                _section('DATA'),
                _box(
                  ListTile(
                    leading: const Icon(Icons.restart_alt_rounded, color: AppColors.navy),
                    title: const Text('Reset learning progress', style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.navy)),
                    subtitle: const Text('Clears lessons and streak. Keeps your ideas.', style: TextStyle(fontSize: 12)),
                    onTap: _reset,
                  ),
                ),
                const SizedBox(height: 24),
                const Center(
                  child: Text('The Entrepreneur  |  Version 1.0.0',
                      style: TextStyle(fontSize: 11.5, color: AppColors.muted)),
                ),
              ],
            ),
    );
  }
}
