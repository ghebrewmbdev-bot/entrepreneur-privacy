import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/case_study.dart';

class ShortCaseDetailScreen extends StatelessWidget {
  final ShortCase shortCase;
  const ShortCaseDetailScreen({super.key, required this.shortCase});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(shortCase.company)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('THE STORY', style: TextStyle(fontFamily: 'monospace', fontSize: 10, color: AppColors.teal, letterSpacing: 1)),
          const SizedBox(height: 8),
          Text(shortCase.story, style: const TextStyle(fontSize: 14, height: 1.65, color: AppColors.ink)),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.navyLight, borderRadius: BorderRadius.circular(14)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('THE LESSON', style: TextStyle(fontFamily: 'monospace', fontSize: 10, color: AppColors.gold, letterSpacing: 1)),
                const SizedBox(height: 8),
                Text(shortCase.lesson, style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic, color: Color(0xFFDCE1EC), height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
