# Screenshot Shot List

Google Play needs at least 2 phone screenshots, and up to 8 is best. Take them from a real build (`flutter run` on a phone or emulator). A 1080 x 1920 or similar portrait size works. Turn on the Pixel or Android screenshot tool, or use the emulator camera button.

Before shooting, complete a few lessons, one daily challenge, and save one idea so the screens look lived in.

| # | Screen | Suggested caption |
|---|--------|-------------------|
| 1 | Home | Learn the skill of innovation, one step a day |
| 2 | Modules list | 10 modules from spotting opportunity to scaling |
| 3 | A lesson (scrolled to the story and takeaway) | Real founder stories and a clear takeaway |
| 4 | A module quiz question | Check what you learned with quick quizzes |
| 5 | Stories, Deep Track | Learn from Spanx, WhatsApp, Canva, Netflix, Alibaba, and Econet |
| 6 | Idea Lab scorecard | Score your idea before you build it |
| 7 | Calculators | Unit economics and break-even in seconds |
| 8 | Daily challenge or Profile | Build a daily habit and earn achievements |

Captions are for overlay text if you add it in an editor. Play does not require captions. Do not show real personal information in screenshots.
