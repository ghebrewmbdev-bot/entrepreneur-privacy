# The Entrepreneur: Play Store Listing

## Pricing and distribution
- App: Free
- Contains in-app purchases: No (for the free launch)
- Contains ads: No
- Contact email: hello@weegix.com
- Website: weegix.com

## App content declarations
- Privacy policy URL: host privacy_policy.html and paste the link
- Data Safety: no personal data collected or shared; all data stays on the device
- Target audience: 13+ / general
- Content rating: expected Everyone
- Category: Education (or Business)

## Store listing text

**Title (30 characters max):** The Entrepreneur

**Short description (80 characters max):**
Spot opportunity, ride the AI wave, and build real market solutions.

**Full description (4000 characters max):**
The Entrepreneur teaches the skill of innovation the way it works in the real world: through real founder stories, concrete best practices, and one small action a day.

Learn to:
- Spot real opportunity in everyday friction and unmet needs
- Read the AI, internet, robotics, and industrial waves reshaping every market
- Validate an idea before building anything, the way Dropbox and Zappos did
- Build a product fast with no-code and AI tools
- Create AI-native products with real moats, honest limits, and sound costs
- Understand investment, unit economics, and when to bootstrap versus raise
- Go to market, price with intention, and win your first 100 customers
- Scale operations, hire for your stage, and know when to say no to growth
- Build for emerging markets, handle rejection, and know when to pivot

What is inside:
- 10 modules and 47 lessons, each with a principle, a real story, best practices, a key takeaway, and an action to try today
- A short quiz for every module so you can check what stuck
- Founder stories: deep dives on Sara Blakely (Spanx), Jan Koum (WhatsApp), Melanie Perkins (Canva), Reed Hastings (Netflix), Jack Ma (Alibaba), and Strive Masiyiwa (Econet), plus 20 short case studies
- Idea Lab: save your ideas, move them from Spark to Launched, and score each one with the Opportunity Scorecard
- Calculators: unit economics (LTV, CAC, payback) and break-even
- Toolkit: 14 templates including a pitch outline, investor email, customer interview script, pre-mortem, and positioning statement, all one tap to copy
- A glossary of 37 plain-language business terms
- 61 daily challenges, a streak, an optional daily reminder, and 20 achievements
- Search across everything

Is it free? Yes. Everything in the app is free, with no ads and no account. Your progress and ideas stay on your phone, and the app works offline.

Educational content only. Nothing in the app is legal, financial, or investment advice.

**Keywords (for your own use in the description):** entrepreneurship, startup, innovation, business skills, AI, investment, pitch deck, founder stories, business model, validation

**Promo text:** Spot the opportunity. Ride the wave. Build the solution.

## What's new (first release, 500 characters max)
First release: 10 modules with 47 lessons and quizzes, 6 founder deep dives and 20 short cases, Idea Lab with scorecard, unit economics and break-even calculators, a practical toolkit, a business glossary, 61 daily challenges with streaks and optional reminders, and achievements. Free, no ads, works offline.
