# Privacy Policy: The Entrepreneur

**Last updated: November 3, 2026**

Weegix Technology Solutions LLC ("Weegix", "we", "us") built The Entrepreneur app. This policy explains what happens to your information when you use it.

## Data We Collect
The Entrepreneur does not collect, transmit, or share any personal data. Everything you create or complete in the app, including completed lessons, daily challenge history, streaks, your saved ideas and their scores, and your reminder settings, is stored locally on your device in a local database. We never see this information and it never leaves your device. There are no accounts, no analytics, and no advertising.

## Daily Reminders
If you turn on the optional daily reminder, the app asks for permission to show notifications. The reminder is scheduled on your device only. No information about you is sent to any server to deliver it. You can turn it off at any time in the app's Settings or in your phone's settings.

## In-App Purchases
The app is currently free. If paid content is added in the future, purchases will be handled entirely by Google Play Billing. Weegix will never see or store your payment card details.

## Permissions
The app may use: the ability to open the weegix.com website or email links from the About screen if you tap them, which hands the link to your browser or email app. All fonts and content are bundled inside the app, so it works fully offline; notifications, used only for the optional daily reminder; and receive boot completed, used only so your reminder keeps working after your phone restarts.

## Children's Privacy
The Entrepreneur is not directed at children under 13. We do not knowingly collect information from anyone of any age, since the app collects no personal data.

## Changes to This Policy
We may update this policy occasionally. Changes will be posted on this page with an updated date.

## Contact Us
Questions about this policy can be sent to hello@weegix.com or through weegix.com.
