# Terms of Service: The Entrepreneur

**Last updated: November 3, 2026**

By downloading or using The Entrepreneur ("the App"), built by Weegix Technology Solutions LLC ("Weegix", "we"), you agree to these terms.

## Educational Content Disclaimer
The Entrepreneur provides general educational content about entrepreneurship, business, and innovation, including founder stories, frameworks, calculators, and templates. Nothing in the App is legal, financial, tax, or investment advice. The calculators and the Opportunity Scorecard are simple planning aids, not predictions. Always consult a qualified professional before making business, legal, or financial decisions.

## Free and Paid Content
The App is currently free to download and use. Weegix may add optional paid content in the future. If that happens, purchases will be processed and billed through Google Play Billing, and refunds will follow Google Play's refund policies rather than being handled directly by Weegix.

## License and Intellectual Property
All content, text, graphics, and code in the App are owned by Weegix or used under license. You may use the App for personal, non-commercial purposes. You may not copy, redistribute, or resell App content. The ideas and notes you enter in the Idea Lab belong to you.

## Acceptable Use
You agree not to reverse-engineer, decompile, or misuse the App, or to use it in any way that violates applicable law.

## Warranty Disclaimer
The App is provided "as is" without warranties of any kind, express or implied. Weegix does not guarantee the App will be error-free or uninterrupted.

## Limitation of Liability
To the maximum extent permitted by law, Weegix is not liable for any indirect, incidental, or consequential damages arising from your use of the App.

## Governing Law
These terms are governed by the laws of the State of Illinois, United States, without regard to conflict of law principles.

## Contact Us
Questions about these terms can be sent to hello@weegix.com or through weegix.com.
