# The Entrepreneur: Setup and Store Notes

## 1. Drop the files in
Your project is at D:\entrepreneur. From this zip, copy over:
- `lib/` (replace the whole folder)
- `assets/` (adds `assets/fonts/`, keeps `assets/icon/`)
- `pubspec.yaml` (google_fonts is removed, fonts section is added)

Then run:
```
flutter clean
flutter pub get
dart run flutter_launcher_icons
flutter analyze
flutter run
```
The local database upgrades from version 2 to 3 automatically (adds a table for quiz scores). Existing installs keep their progress.

## 2. Android files
- `android_setup/build.gradle.kts` replaces `android/app/build.gradle.kts`. It keeps Java 17 on both Java and Kotlin, core library desugaring on, release signing that activates when `android/key.properties` exists, and now targets Android 16 (API 36) as Google Play requires.
- `android_setup/AndroidManifest_additions.xml` lists three things to add to `android/app/src/main/AndroidManifest.xml`: the notification permissions, the link queries, and the two reminder receivers. Without the receivers the daily reminder will not fire. Without the queries the About Weegix links do nothing on Android 11+.

### If the build complains about API 36
Targeting API 36 needs a recent toolchain. If Gradle says the Android Gradle Plugin does not support compileSdk 36:
1. Run `flutter upgrade`, then `flutter --version` to confirm.
2. In `android/settings.gradle.kts` set the `com.android.application` plugin version to 8.9.1 or newer.
3. In `android/gradle/wrapper/gradle-wrapper.properties` use Gradle 8.11.1 or newer.
4. Run `flutter clean` and build again.
If you only want a quick local test build first, you can temporarily set both `compileSdk` and `targetSdk` back to `flutter.compileSdkVersion` and `flutter.targetSdkVersion`, but do not upload that build to Play.

## 3. Release signing for the Play upload
Play rejects debug-signed builds. Create a keystore once (you can reuse your SciForge upload key, or make a new one):
```
keytool -genkey -v -keystore D:\keys\entrepreneur-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```
Create `android/key.properties`:
```
storePassword=YOUR_PASSWORD
keyPassword=YOUR_PASSWORD
keyAlias=upload
storeFile=D:/keys/entrepreneur-upload.jks
```
Never commit key.properties or the keystore, and back the keystore up somewhere safe. Then build the Play bundle:
```
flutter build appbundle --release
```
The file is at `build/app/outputs/bundle/release/app-release.aab`. Bump the `+1` in `pubspec.yaml` (version: 1.0.0+1) on every re-upload.

## 4. Play launch checklist
1. Play Console, Create app: name "The Entrepreneur", language English, App, Free, accept declarations. Use the Weegix LLC organization account.
2. Testing requirement: if your developer account is a personal account created after November 2023, Google requires a closed test with at least 12 testers for 14 days before production. Organization accounts are normally exempt. Check your Console dashboard and follow whatever it shows.
3. Store listing: paste text from `store_listing.md`. Upload the 512x512 icon and the 1024x500 feature graphic from `store_assets_extra/`.
4. Screenshots: at least 2 phone screenshots (up to 8). See `screenshots_guide.md` for a shot list. Take them from a real build, not from the HTML preview.
5. Privacy policy URL: upload `privacy_policy.html` to weegix.com (for example weegix.com/entrepreneur/privacy) and paste the link. Do the same for the terms page.
6. App content: Data safety (no data collected or shared), Ads (No), Target audience (13 and over), Content rating questionnaire (expected Everyone), Government apps (No), Financial features (No: the app teaches business and has calculators but does not offer financial services, lending, or advice. If the form asks, say it is educational).
7. Release, Production (or Internal testing first): upload the .aab, add release notes from `store_listing.md`, review and roll out.
8. Contact email: use hello@weegix.com in the Play listing so it matches the app and the policies.

## 5. Free launch, paid later
Every module has `isFree: true` in `lib/data/modules_catalog.dart`. To make a module paid later, set its `isFree` to `false`. The lock badges, the paywall, and purchase handling are already wired:
1. Create a one-time (non-consumable) in-app product in Play Console with the exact id `com.weegix.entrepreneur.unlock_all`.
2. Set a price and activate it, and upload to at least an internal testing track (purchases do not work before that).
3. Update the Play Console in-app purchases declaration, the Data Safety form if needed, the store text, and the Terms of Service paragraph about paid content.

When you do this, frame it as new premium modules being added rather than locking what people already had. Note: the billing library adds a billing permission to the app even while everything is free. That is normal. Keep "Contains in-app purchases" set to No until you create a product.

## 6. Fonts
Inter and Space Grotesk are bundled in `assets/fonts/` with their SIL Open Font License files. Nothing is downloaded at runtime.

## 7. Known limits
- The daily reminder is scheduled from your phone's local time each time the app opens. After a daylight saving change it corrects itself the next time the app is opened.
- I could not run Flutter in my workspace, so I checked the Dart for syntax (strings, brackets, imports) and for banned dashes, but could not compile it. Please run `flutter analyze` and `flutter run` once and send me anything the compiler flags. Warnings about `withOpacity` being deprecated are harmless.
- The bundled fonts are variable fonts. If headings look the same weight on your phone, tell me and I will swap in static weights.
