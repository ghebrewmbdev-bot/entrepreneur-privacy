# The Entrepreneur: Complete Feature List

## Learn
- 10 modules, 47 lessons: Spotting Opportunity, The Technology Wave, Validating the Idea, Building the Product, Business Model and Investment, Go-to-Market, Scaling and Operations, Building AI-Native Products, Global and Emerging Markets, Resilience, Pivots, and Ethics
- Every lesson: principle, real founder story, best practices, key takeaway, a "try this today" action, and a reflection prompt
- A 3-question quiz at the end of every module, with explanations and a saved best score
- Glossary of 37 plain-language business terms, searchable
- Mark as read, plus a Next lesson button to keep moving
- Continue Learning card on Home jumps to your next unfinished lesson
- Today's Wave card: a daily-rotating lesson from the Technology Wave module
- Search across lessons, founder chapters, short cases, toolkit items, and glossary terms

## Stories
- Deep Track: 6 founder deep dives, Sara Blakely (Spanx), Jan Koum (WhatsApp), Melanie Perkins (Canva), Reed Hastings and Marc Randolph (Netflix), Jack Ma (Alibaba), and Strive Masiyiwa (Econet)
- Short Track: 20 short case studies (Airbnb, Canva, Slack, Dropbox, Kodak, Pebble, Superhuman, Basecamp, Instagram, M-Pesa, Dyson, Dollar Shave Club, Mailchimp, Lego, Grameen Bank, Twitter and Odeo, Fujifilm, and more)

## Build
- Idea Lab: save ideas with problem, first customer, solution, notes
- Stage pipeline: Spark, Validating, Building, Launched, Parked
- Opportunity Scorecard: rate Pain, Market size, Timing, and Reach, get a 0 to 100 score and a plain-language verdict naming your weakest area
- Calculators: Unit Economics (LTV, LTV to CAC, payback) and Break-even
- Toolkit: 14 copy-to-clipboard templates (problem statement, positioning, smoke test, interview script, unit economics, pitch deck outline, four-sentence pitch, investor email, pre-mortem, AI feature test set, hiring checklist, culture filter, growth no-list, trust promises)

## Habit
- 61 rotating daily challenges, all browsable
- Daily streak (counts through yesterday so it never shows zero first thing in the morning), longest streak
- Optional daily reminder notification at a time you choose (scheduled on the phone only)
- 20 achievements computed from real progress, including quiz achievements
- Profile with streak, lessons, ideas, and per-module progress

## App
- First-launch onboarding (4 slides, skippable)
- Settings: reminder toggle and time, reset learning progress (keeps ideas), version
- About Weegix screen (shared Weegix template) with The Entrepreneur marked as the current app
- Fonts (Inter and Space Grotesk) are bundled, so there is no runtime font download and the app works fully offline
- All progress stored locally in SQLite (database version 3), no account, no ads, no data collected
- All modules currently free. The paywall, purchase service, and lock badges are built and dormant, ready to switch on (see SETUP_AND_STORE_NOTES.md)

## Content accuracy
Stories were checked against published sources in November 2026. Where a story is an illustration rather than a documented event, the lesson says so ("Picture this" or "This is an illustrative scenario"). Where a figure is widely reported but varies by source, the text says "reported" or "about".

## Still to do outside the code
See SETUP_AND_STORE_NOTES.md, section "Play launch checklist".
